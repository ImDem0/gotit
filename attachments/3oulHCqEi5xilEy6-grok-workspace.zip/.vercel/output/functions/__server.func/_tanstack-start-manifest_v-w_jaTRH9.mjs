//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-w_jaTRH9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/author",
			"/check",
			"/courses",
			"/faq",
			"/materials"
		],
		preloads: [
			"/assets/index-DmJn3k-b.js",
			"/assets/useSelector-B_P3tCcN.js",
			"/assets/matchContext-XtG0RFUp.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DmJn3k-b.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BJlyipR6.js", "/assets/course-row-tFfy9vv-.js"]
	},
	"/check": {
		filePath: "/workspace/src/routes/check.tsx",
		children: void 0,
		preloads: ["/assets/check-OMdbu9LN.js"]
	},
	"/courses": {
		filePath: "/workspace/src/routes/courses.tsx",
		children: ["/courses/$slug", "/courses/"],
		preloads: ["/assets/courses-CSoxptv-.js"]
	},
	"/faq": {
		filePath: "/workspace/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-De2g0OlA.js", "/assets/chevron-down-EPkUacZ8.js"]
	},
	"/materials": {
		filePath: "/workspace/src/routes/materials.tsx",
		children: ["/materials/$slug", "/materials/"],
		preloads: ["/assets/materials-CSoxptv-.js"]
	},
	"/courses/$slug": {
		filePath: "/workspace/src/routes/courses.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/courses._slug-CT21tNsr.js",
			"/assets/chevron-down-EPkUacZ8.js",
			"/assets/course-row-tFfy9vv-.js",
			"/assets/catalog-CK0vt4jD.js"
		]
	},
	"/materials/$slug": {
		filePath: "/workspace/src/routes/materials.$slug.tsx",
		children: void 0,
		preloads: ["/assets/materials._slug-BFU9REoG.js"]
	},
	"/courses/": {
		filePath: "/workspace/src/routes/courses.index.tsx",
		children: void 0,
		preloads: [
			"/assets/courses.index-BDqG27s2.js",
			"/assets/course-row-tFfy9vv-.js",
			"/assets/catalog-CK0vt4jD.js"
		]
	},
	"/materials/": {
		filePath: "/workspace/src/routes/materials.index.tsx",
		children: void 0,
		preloads: ["/assets/materials.index-BezORx8c.js"]
	}
} });
//#endregion
export { tsrStartManifest };
