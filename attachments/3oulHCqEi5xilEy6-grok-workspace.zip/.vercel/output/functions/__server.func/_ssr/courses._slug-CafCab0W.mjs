import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Button, c as DemoBanner, d as Spinner, f as cn, g as categoryLabel, i as useProgress, l as Meter, r as Route$2, s as Container } from "./router-fAyq4BGp.mjs";
import { i as formatPrice, n as demoOrderId, r as formatHours, t as CourseRow } from "./course-row-0-RJT9Fd.mjs";
import { n as relatedCourses } from "./catalog-DRie1qEJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses._slug-CafCab0W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EnrollPanel({ course }) {
	const { state, ready, update } = useProgress();
	const enrolled = state.enrolled.includes(course.slug);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [agree, setAgree] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [pending, setPending] = (0, import_react.useState)(false);
	const done = (state.lessons[course.slug] ?? []).length;
	async function onSubmit(event) {
		event.preventDefault();
		const next = {};
		if (name.trim().length < 2) next.name = "Напишите имя — хотя бы два символа. Оно никуда не сохранится.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Проверьте почту: нужен обычный адрес с точкой в домене.";
		if (!agree) next.agree = "Подтвердите, что понимаете: оплата не проводится.";
		setErrors(next);
		if (Object.keys(next).length) return;
		setPending(true);
		await new Promise((resolve) => setTimeout(resolve, 650));
		update((current) => ({
			...current,
			enrolled: current.enrolled.includes(course.slug) ? current.enrolled : [...current.enrolled, course.slug]
		}));
		setPending(false);
		setName("");
		setEmail("");
		toast("Запись осталась только в этом браузере");
	}
	function clearEnrollment() {
		update((current) => ({
			...current,
			enrolled: current.enrolled.filter((slug) => slug !== course.slug)
		}));
		toast("Демонстрационная запись снята");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-3xl border border-line bg-surface p-5 lg:sticky lg:top-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Демонстрационная цена"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "display mt-1 text-4xl text-fg",
				children: formatPrice(course.price)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: course.format
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
					value: ready ? done : 0,
					max: course.lessons.length,
					label: "Отмечено уроков в браузере"
				})
			}),
			enrolled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DemoBanner, { children: [
					"Запись ",
					demoOrderId(course.slug),
					" сохранена локально. Деньги не списывались, письмо не отправлялось."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: clearEnrollment,
					children: "Снять демо-запись"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 space-y-3",
				onSubmit,
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBanner, { children: "Имя и почта нужны только чтобы показать сценарий. Мы не записываем их даже в браузер." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "enroll-name",
							className: "mb-1 block text-sm",
							children: "Имя"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "enroll-name",
							className: "field",
							autoComplete: "name",
							value: name,
							"aria-invalid": Boolean(errors.name),
							"aria-describedby": errors.name ? "enroll-name-error" : void 0,
							onChange: (event) => setName(event.target.value)
						}),
						errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "enroll-name-error",
							className: "mt-1 text-sm text-danger",
							role: "alert",
							children: errors.name
						}) : null
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "enroll-email",
							className: "mb-1 block text-sm",
							children: "Почта"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "enroll-email",
							className: "field",
							type: "email",
							autoComplete: "email",
							inputMode: "email",
							value: email,
							"aria-invalid": Boolean(errors.email),
							"aria-describedby": errors.email ? "enroll-email-error" : void 0,
							onChange: (event) => setEmail(event.target.value)
						}),
						errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							id: "enroll-email-error",
							className: "mt-1 text-sm text-danger",
							role: "alert",
							children: errors.email
						}) : null
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-3 text-sm leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1",
							checked: agree,
							onChange: (event) => setAgree(event.target.checked)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Понимаю, что это демонстрация и реальная оплата не выполняется." })]
					}),
					errors.agree ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						role: "alert",
						children: errors.agree
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: pending,
						"aria-busy": pending,
						children: [pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : null, pending ? "Оформляем демо" : "Оформить демо-запись"]
					})
				]
			})
		]
	});
}
function CoursePage() {
	const { course } = Route$2.useLoaderData();
	const related = relatedCourses(course.slug);
	const { state, update } = useProgress();
	const done = state.lessons[course.slug] ?? [];
	const [open, setOpen] = (0, import_react.useState)(0);
	function toggleLesson(index) {
		update((current) => {
			const prev = current.lessons[course.slug] ?? [];
			const next = prev.includes(index) ? prev.filter((item) => item !== index) : [...prev, index];
			return {
				...current,
				lessons: {
					...current.lessons,
					[course.slug]: next
				}
			};
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-10 md:py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "text-sm text-muted",
					"aria-label": "Хлебные крошки",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/courses",
							className: "prose-link",
							children: "Курсы"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							children: " / "
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: course.title })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_20rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-accent",
								children: [
									categoryLabel(course.categoryId),
									" · ",
									course.level,
									" · ",
									formatHours(course.hours)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "display mt-3 text-4xl text-fg sm:text-6xl",
								children: course.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-prose text-lg text-muted",
								children: course.summary
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:row-span-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnrollPanel, { course })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-10",
							children: [
								course.description.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-prose leading-relaxed",
									children: paragraph
								}, paragraph)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display text-3xl",
									children: "Для кого"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-prose text-muted",
									children: course.audience
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display text-3xl",
									children: "Что останется после курса"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 max-w-prose list-disc space-y-2 ps-5 text-muted",
									children: course.outcomes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display text-3xl",
									children: "Навыки"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 flex flex-wrap gap-2",
									children: course.skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "rounded-full border border-line px-3 py-2 text-sm",
										children: skill
									}, skill))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "display text-3xl",
										children: "Программа"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 max-w-prose text-sm text-muted",
										children: "Отметка «урок пройден» хранится только в этом браузере и не требует записи."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 border-t border-line",
										children: course.lessons.map((lesson, index) => {
											const isOpen = open === index;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "border-b border-line",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-3 py-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "mt-3 flex items-center gap-2 text-sm text-muted",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "checkbox",
															checked: done.includes(index),
															onChange: () => toggleLesson(index)
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "sr-only",
															children: ["Урок пройден: ", lesson.title]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "flex min-h-11 flex-1 items-center justify-between gap-3 text-left",
														"aria-expanded": isOpen,
														onClick: () => setOpen(isOpen ? -1 : index),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "block text-fg",
															children: lesson.title
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-sm text-muted",
															children: [lesson.minutes, " мин"]
														})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-5 shrink-0 transition-transform duration-200", isOpen && "rotate-180") })]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: cn("fold", isOpen && "open"),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "fold-inner",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "max-w-prose pb-4 ps-8 text-muted",
															children: lesson.about
														})
													})
												})]
											}, lesson.title);
										})
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "rounded-3xl border border-line bg-surface-2 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg",
										children: "Кто ведёт в этом сценарии"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 max-w-prose text-muted",
										children: [
											"Иванко Сергей Романович — вымышленный автор платформы. У курса нет реального преподавателя, диплома и лицензии.",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/author",
												className: "prose-link",
												children: "Читать оговорку"
											}),
											"."
										]
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-3xl",
						children: "Рядом по смыслу"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 border-t border-line",
						children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseRow, { course: item }, item.slug))
					})]
				})
			]
		})
	});
}
//#endregion
export { CoursePage as component };
