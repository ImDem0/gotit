import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Button, c as DemoBanner, d as Spinner, f as cn, s as Container } from "./router-fAyq4BGp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-6FGHEgZC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var topics = [
	"Вопрос о демо",
	"Ошибка на сайте",
	"Тема для материала",
	"Другое"
];
function ContactForm() {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [topic, setTopic] = (0, import_react.useState)(topics[0]);
	const [message, setMessage] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [pending, setPending] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		const next = {};
		if (name.trim().length < 2) next.name = "Добавьте имя — хотя бы два символа.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Нужна почта в обычном виде.";
		if (message.trim().length < 12) next.message = "Напишите пару слов подробнее, хотя бы 12 символов.";
		setErrors(next);
		if (Object.keys(next).length) {
			toast.error("Проверьте поля формы");
			return;
		}
		setPending(true);
		await new Promise((resolve) => setTimeout(resolve, 600));
		setPending(false);
		setSent(true);
		setName("");
		setEmail("");
		setMessage("");
		toast("Это демонстрация: сообщение никуда не ушло");
	}
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-line bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "display text-3xl",
				children: "Сообщение не отправлено"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-prose text-muted",
				children: "Форма отработала локально и показала этот экран. На сервер ничего не уходило, почта не сохранялась. Так и задумано, пока у проекта нет приёма обращений."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				className: "mt-5",
				variant: "secondary",
				onClick: () => setSent(false),
				children: "Заполнить ещё раз"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-4",
		onSubmit,
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBanner, { children: "Поля проверяются в браузере. После «отправки» текст уничтожается и никуда не передаётся." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "contact-name",
					className: "mb-1 block text-sm",
					children: "Имя"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "contact-name",
					className: "field",
					autoComplete: "name",
					value: name,
					"aria-invalid": Boolean(errors.name),
					onChange: (event) => setName(event.target.value)
				}),
				errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-danger",
					role: "alert",
					children: errors.name
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "contact-email",
					className: "mb-1 block text-sm",
					children: "Почта"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "contact-email",
					className: "field",
					type: "email",
					autoComplete: "email",
					value: email,
					"aria-invalid": Boolean(errors.email),
					onChange: (event) => setEmail(event.target.value)
				}),
				errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-danger",
					role: "alert",
					children: errors.email
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "contact-topic",
				className: "mb-1 block text-sm",
				children: "Тема"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				id: "contact-topic",
				className: "select",
				value: topic,
				onChange: (event) => setTopic(event.target.value),
				children: topics.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "contact-message",
					className: "mb-1 block text-sm",
					children: "Сообщение"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "contact-message",
					className: "field",
					value: message,
					"aria-invalid": Boolean(errors.message),
					onChange: (event) => setMessage(event.target.value)
				}),
				errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-danger",
					role: "alert",
					children: errors.message
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				disabled: pending,
				"aria-busy": pending,
				children: [pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : null, pending ? "Проверяем" : "Показать демо-отправку"]
			})
		]
	});
}
var faqItems = [
	{
		q: "Это лицензированная школа?",
		a: "Нет. «Интервал» — демонстрационная учебная платформа. У проекта нет реальной образовательной лицензии, набора студентов и проверок дипломов. Материалы написаны как практические объяснения, а не как официальная программа."
	},
	{
		q: "Цены и кнопка записи настоящие?",
		a: "Нет. Цены показывают, как мог бы выглядеть каталог. Запись сохраняется только в вашем браузере. Карту, код и паспорт мы не просим, платёж не создаётся."
	},
	{
		q: "Куда уходит сообщение из формы?",
		a: "Никуда. Форма проверяет поля и показывает, как выглядело бы подтверждение. Текст не отправляется на сервер и не сохраняется."
	},
	{
		q: "Сохранится ли прогресс уроков и теста?",
		a: "Только на этом устройстве, в локальном хранилище браузера. Если очистить данные сайта, отметки пропадут. Общего аккаунта нет."
	},
	{
		q: "Нужна ли техническая подготовка?",
		a: "Нет. Курсы рассчитаны на обычную почту, банк, мессенджеры и покупки. Термины поясняются на месте. Инженерная настройка сетей в программу не входит."
	},
	{
		q: "Можно пройти проверку, ничего не покупая?",
		a: "Да. Тест открыт без записи. Он учебный: не выдаёт сертификат и не измеряет «официальный уровень». После ответов будут пояснения и ссылки на курсы по тем местам, где ответ не совпал."
	},
	{
		q: "В примерах есть опасные ссылки?",
		a: "Нет. Адреса вроде severpost-pay.example вымышлены. Зона .example зарезервирована для документации. Мы не просим по ним переходить и не размещаем рабочий вредоносный код."
	},
	{
		q: "Что делать, если деньги уже ушли мошенникам?",
		a: "Свяжитесь со своим банком по номеру на карте или в официальном приложении, не по телефону из подозрительного сообщения. Сохраните сумму и время операции. Для контекста о работе финансового сектора с такими случаями можно посмотреть раздел информационной безопасности Банка России. Этот сайт не принимает заявления и не заменяет банк или полицию."
	}
];
function FaqList() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-y border-line",
		children: faqItems.map((item, index) => {
			const isOpen = open === index;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line last:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-h-11 w-full items-center justify-between gap-4 py-4 text-left",
					"aria-expanded": isOpen,
					onClick: () => setOpen(isOpen ? null : index),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-lg text-fg",
						children: item.q
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
						className: cn("size-5 shrink-0 text-muted transition-transform duration-200", isOpen && "rotate-180"),
						"aria-hidden": true
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("fold", isOpen && "open"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "fold-inner",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-prose pb-4 leading-relaxed text-muted",
							children: item.a
						})
					})
				})]
			}, item.q);
		})
	});
}
function FaqPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-14 py-12 md:py-16 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Вопросы"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 text-4xl text-fg sm:text-5xl",
					children: "Коротко о том, чего сайт не делает"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-4xl",
					children: "Написать"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Форма для проверки полей. Живого ящика за ней нет."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})
				})
			] })]
		})
	});
}
//#endregion
export { FaqPage as component };
