import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as articles, p as articleKinds, s as Container } from "./router-fAyq4BGp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/materials.index-clxRoDLF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MaterialsPage() {
	const [kind, setKind] = (0, import_react.useState)("Все");
	const list = articles.filter((article) => kind === "Все" || article.kind === kind);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-12 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Читальня"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl",
					children: "Короткие материалы без записи на курс"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-prose text-lg text-muted",
					children: "Чек-листы и разборы можно читать отдельно. Это не новости: приёмы общие, а детали схем меняются. Где есть опора, стоит ссылка."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-wrap gap-2",
					role: "group",
					"aria-label": "Тип материала",
					children: articleKinds.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip",
						"aria-pressed": kind === item,
						onClick: () => setKind(item),
						children: item
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted",
					"aria-live": "polite",
					children: list.length === 0 ? "Таких материалов нет" : `Материалов: ${list.length}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 border-t border-line",
					children: list.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/materials/$slug",
							params: { slug: article.slug },
							className: "grid gap-2 py-6 no-underline md:grid-cols-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-accent md:col-span-3",
								children: [
									article.kind,
									" · ",
									article.minutes,
									" мин"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "md:col-span-9",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "display block text-3xl text-fg",
									children: article.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block max-w-prose text-muted",
									children: article.lead
								})]
							})]
						})
					}, article.slug))
				})
			]
		})
	});
}
//#endregion
export { MaterialsPage as component };
