import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as categoryLabel } from "./router-fAyq4BGp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/course-row-0-RJT9Fd.js
var import_jsx_runtime = require_jsx_runtime();
var money = new Intl.NumberFormat("ru-RU");
function formatPrice(value) {
	return `${money.format(value)} ₽`;
}
function formatHours(value) {
	const text = Number.isInteger(value) ? String(value) : String(value).replace(".", ",");
	const whole = Math.floor(value);
	const mod10 = whole % 10;
	const mod100 = whole % 100;
	let word = "часов";
	if (mod100 < 11 || mod100 > 14) {
		if (mod10 === 1) word = "час";
		else if (mod10 >= 2 && mod10 <= 4) word = "часа";
	}
	return `${text} ${word}`;
}
function demoOrderId(slug) {
	let n = 0;
	for (const ch of slug) n = (n * 33 + ch.charCodeAt(0)) % 9e3;
	return `ДЕМО-${1e3 + n}`;
}
function CourseRow({ course }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/courses/$slug",
		params: { slug: course.slug },
		className: "group grid gap-3 border-b border-line py-6 no-underline transition-colors duration-200 hover:bg-surface md:grid-cols-12 md:items-baseline md:gap-6 md:px-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent",
					children: categoryLabel(course.categoryId)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						course.level,
						" · ",
						formatHours(course.hours)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "display text-2xl text-fg group-hover:text-accent",
					children: course.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
					children: course.summary
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "display text-2xl text-fg md:col-span-3 md:text-end",
				children: [formatPrice(course.price), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-sans text-xs font-normal tracking-normal text-muted",
					children: "демонстрационная цена"
				})]
			})
		]
	});
}
//#endregion
export { formatPrice as i, demoOrderId as n, formatHours as r, CourseRow as t };
