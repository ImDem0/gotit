import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, Y as notFound, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Menu, i as Moon, n as TriangleAlert, r as Sun, t as X } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses-C-0s8QNz.js
var categories = [
	{
		id: "osnovy",
		label: "Основы"
	},
	{
		id: "dannye",
		label: "Личные данные"
	},
	{
		id: "moshennichestvo",
		label: "Мошенничество"
	},
	{
		id: "dostup",
		label: "Пароли и вход"
	},
	{
		id: "obshchenie",
		label: "Общение"
	},
	{
		id: "platezhi",
		label: "Платежи"
	},
	{
		id: "ustroystva",
		label: "Устройства"
	},
	{
		id: "ii",
		label: "Искусственный интеллект"
	}
];
function categoryLabel(id) {
	return categories.find((item) => item.id === id)?.label ?? id;
}
var courses = [
	{
		slug: "osnovy",
		title: "Основы киберграмотности",
		summary: "Спокойная карта цифровой жизни: что защищать в первую очередь и какие привычки реально снижают бытовой риск.",
		description: ["Курс для тех, кто пользуется почтой, банком, мессенджерами и госуслугами, но не хочет разбираться в этом как инженер. Мы разбираем не «кибервойны», а обычные точки, где человек теряет деньги, доступ к аккаунту или лишние сведения о себе.", "После курса остаётся короткий личный порядок: что проверить на телефоне, какие письма не открывать с порога и куда смотреть, если что-то уже пошло не так."],
		categoryId: "osnovy",
		level: "начальный",
		hours: 6,
		price: 3900,
		format: "Самостоятельный темп, короткие уроки и учебные разборы. Сертификат в демонстрации не выдаётся.",
		popular: true,
		audience: "Тем, кто хочет общую опору до узких тем вроде платежей или ИИ.",
		outcomes: [
			"Отличаете бытовую цифровую гигиену от кинематографических «взломов».",
			"Собираете свой короткий чек-лист на неделю.",
			"Понимаете, когда достаточно паузы, а когда пора звонить в банк по номеру с карты."
		],
		skills: [
			"оценка ситуации",
			"цифровой след",
			"приоритеты защиты",
			"куда обращаться"
		],
		lessons: [
			{
				title: "Что именно стоит защищать",
				minutes: 18,
				about: "Аккаунт, деньги, переписка, фото, документы и доступ к телефону — разные ценности. Смотрим, что потеря больнее всего именно вам."
			},
			{
				title: "Пауза как навык",
				minutes: 16,
				about: "Срочные просьбы устроены так, чтобы вы не успели подумать. Учимся отделять настоящий дедлайн от давления в тексте."
			},
			{
				title: "Канал и отправитель",
				minutes: 20,
				about: "Имя в шапке письма ничего не гарантирует. Сверяем адрес, приложение и то, ждали ли вы это сообщение."
			},
			{
				title: "Секреты, которые нельзя пересылать",
				minutes: 18,
				about: "Пароль, код из SMS, полное фото карты и сканы документов не становятся безопаснее от того, что их просит «поддержка»."
			},
			{
				title: "Личный порядок на семь дней",
				minutes: 22,
				about: "Короткий план: блокировка экрана, обновления, список важных аккаунтов, запасной способ войти и человек, с которым можно спокойно перепроверить странное сообщение."
			}
		]
	},
	{
		slug: "lichnye-dannye",
		title: "Защита личных данных и цифровой личности",
		summary: "Какие сведения о вас уже размазаны по сервисам и как отдавать их реже, не отказываясь от удобных приложений.",
		description: ["Цифровая личность — это не аватар, а набор следов: телефон, адрес, фото документа, ответы на «секретные вопросы», геометки, чеки. Курс показывает, где эти следы появляются в обычной жизни и что можно сократить без параноидального режима.", "Отдельно разбираем, чем персональные данные отличаются от «просто анкеты в интернете», и почему весёлые тесты в соцсетях иногда спрашивают то же самое, что формы восстановления доступа."],
		categoryId: "dannye",
		level: "начальный",
		hours: 5,
		price: 5400,
		format: "Самостоятельный темп и практические решения «отдать / не отдавать». Юридическая консультация не оказывается.",
		popular: false,
		audience: "Тем, кто заполняет анкеты, регистрируется на сервисах и хранит документы в телефоне.",
		outcomes: [
			"Видите разницу между данными, которые нужны сервису, и данными, которые он просто просит.",
			"Умеете проверять разрешения приложений проще, чем «в настройках всё выключить».",
			"Меньше оставляете ответов, из которых собирается запасной вход в аккаунт."
		],
		skills: [
			"минимизация данных",
			"разрешения приложений",
			"восстановление доступа",
			"цифровой след"
		],
		lessons: [
			{
				title: "Из чего складывается цифровой след",
				minutes: 18,
				about: "Регистрации, доставка, чеки, фото, комментарии и геолокация. Не всё из этого опасно, но всё это можно сопоставить."
			},
			{
				title: "Анкета, которая спрашивает лишнее",
				minutes: 16,
				about: "Как отличать обязательное поле от привычки сервиса собрать побольше и что отвечать, если без поля кнопка не нажимается."
			},
			{
				title: "Секретные вопросы",
				minutes: 14,
				about: "Девичья фамилия, кличка питомца и школа — плохие секреты: их часто знают другие люди или их легко выведать игрой."
			},
			{
				title: "Документы в телефоне",
				minutes: 20,
				about: "Где хранить фото паспорта, кому его не отправлять и почему мессенджер — не сейф, даже если чат «только для своих»."
			},
			{
				title: "Разрешения без охоты на ведьм",
				minutes: 16,
				about: "Камера, контакты, геопозиция и микрофон: оставляем то, без чего приложение не работает по смыслу, и убираем остальное."
			}
		]
	},
	{
		slug: "fishing",
		title: "Как распознавать фишинг и интернет-мошенничество",
		summary: "Учебные письма, SMS и звонки: какие приёмы повторяются и как проверять их, не переходя по чужим ссылкам.",
		description: ["Фишинг — это маска знакомого сервиса. Человека просят срочно перейти, оплатить, назвать код или «подтвердить личность». Курс тренирует глаз на этих приёмах. Все примеры вымышлены, ссылки не ведут на живые схемы.", "Мы не обещаем, что после курса вы узнаете любой новый трюк. Угрозы меняются. Зато остаётся устойчивая проверка: кто пишет, чего хочет и можно ли сделать то же самое самим, открыв официальное приложение."],
		categoryId: "moshennichestvo",
		level: "средний",
		hours: 4.5,
		price: 4200,
		format: "Разборы сообщений и короткие тренировки на вымышленных примерах.",
		popular: true,
		audience: "Тем, кто уже получает подозрительные SMS, звонки «из банка» и письма о доставке.",
		outcomes: [
			"Называете конкретные признаки, а не просто «что-то странное».",
			"Проверяете доставку, банк и аккаунт обходным путём.",
			"Знаете, что не делать в первые минуты, если уже нажали не туда."
		],
		skills: [
			"разбор писем",
			"поддельные страницы",
			"социальная инженерия",
			"первые действия"
		],
		lessons: [
			{
				title: "Костюм организации",
				minutes: 16,
				about: "Логотип, тон и имя отправителя копируются легко. Смотрим, что подделать трудно, а что — нет."
			},
			{
				title: "Срочность и мелкая сумма",
				minutes: 14,
				about: "«Осталось два часа» и «всего 49 рублей» снижают бдительность. Разбираем, зачем так пишут."
			},
			{
				title: "Ссылка, которую лучше не открывать",
				minutes: 18,
				about: "Как выглядит подмена адреса в учебном примере и почему надёжнее набрать сервис самим. Настоящие вредоносные адреса в курсе не используются."
			},
			{
				title: "Звонок и голос",
				minutes: 16,
				about: "Голос может звучать убедительно, в том числе из-за записи или синтеза. Правило то же: кладёте трубку и перезваниваете по номеру с карты или из официального приложения."
			},
			{
				title: "Если уже перешли или назвали код",
				minutes: 18,
				about: "Банк по номеру с карты, смена пароля с чистого устройства, предупреждение близких. Без стыда и без «секретных горячих линий» из самого сообщения."
			}
		]
	},
	{
		slug: "paroli",
		title: "Надёжные пароли и многофакторная аутентификация",
		summary: "Длина, уникальность, менеджер паролей и второй фактор — без мифа, что пароль нужно менять каждые тридцать дней.",
		description: ["Старые советы вроде «обязательно спецсимвол и плановая смена раз в квартал» хуже помогают, чем один длинный уникальный пароль на каждый сервис. Курс опирается на направление рекомендаций NIST по цифровым идентичностям: запоминаемый секрет должен быть длинным, а не просто пёстрым, и его не следует заставлять менять без причины.", "Второй фактор разбираем спокойно: приложение-генератор кодов или ключ обычно устойчивее SMS, но SMS всё равно лучше, чем один только пароль."],
		categoryId: "dostup",
		level: "начальный",
		hours: 3,
		price: 2900,
		format: "Короткие уроки и упражнение на выбор стратегии. Свои настоящие пароли вводить не нужно.",
		popular: true,
		audience: "Тем, кто использует один пароль «чтобы не забыть» или хранит его в переписке.",
		outcomes: [
			"Отличаете сильную стратегию от сложного, но повторно используемого пароля.",
			"Понимаете, зачем менеджер паролей и чем он не является.",
			"Включаете второй фактор там, где он есть, начиная с почты и банка."
		],
		skills: [
			"уникальные пароли",
			"менеджер паролей",
			"коды входа",
			"запасные коды"
		],
		lessons: [
			{
				title: "Почему сложность без уникальности слабая",
				minutes: 14,
				about: "Password123! выглядит серьёзно и бесполезен, если он один на почту, магазин и банк."
			},
			{
				title: "Длина и фраза",
				minutes: 12,
				about: "Несколько обычных слов, которые не являются цитатой из вашей биографии, часто лучше короткой каши из символов."
			},
			{
				title: "Менеджер паролей без магии",
				minutes: 16,
				about: "Он помнит уникальные пароли. Мастер-пароль и доступ к самому менеджеру остаются вашей ответственностью."
			},
			{
				title: "Второй фактор",
				minutes: 16,
				about: "Код из приложения, ключ, SMS. Что выбрать, если сервис предлагает несколько способов, и почему код из сообщения нельзя диктовать звонящему."
			},
			{
				title: "Запасной вход",
				minutes: 12,
				about: "Коды восстановления хранят не в том же чате, где просят «скинуть код, я на совещании»."
			}
		]
	},
	{
		slug: "socseti",
		title: "Безопасность социальных сетей и мессенджеров",
		summary: "Аккаунты, пересылка кодов, публичные анкеты и привычка не решать чужую срочность в личных сообщениях.",
		description: ["Мессенджер ощущается как кухня: там свои. Именно поэтому в нём хорошо работают схемы «я твой друг, пришли код» и «мама, срочно нужны деньги на новый номер». Курс разбирает настройки видимости и сценарии, в которых знакомый тон ничего не доказывает.", "Отдельно говорим о викторинах, розыгрышах и просьбах перейти «в поддержку» внутри переписки."],
		categoryId: "obshchenie",
		level: "начальный",
		hours: 4,
		price: 3600,
		format: "Сценарии переписок и настройки, которые можно проверить в тот же день.",
		popular: false,
		audience: "Тем, кто много переписывается и ведёт хотя бы одну социальную сеть.",
		outcomes: [
			"Не отправляете коды и пароли, даже если просит знакомое имя.",
			"Сужаете, кто видит номер, почту и список друзей, если это вам нужно.",
			"Проверяете необычную просьбу о деньгах вторым каналом, который открываете сами."
		],
		skills: [
			"переписки",
			"приватность профиля",
			"коды подтверждения",
			"проверка личности"
		],
		lessons: [
			{
				title: "Знакомое имя — не доказательство",
				minutes: 14,
				about: "Аккаунт могли занять, номер могли подменить, а сообщение могли написать не тому человеку."
			},
			{
				title: "Код, который нельзя пересылать",
				minutes: 12,
				about: "Если код пришёл вам, он подтверждает ваше действие, а не «помощь другу на совещании»."
			},
			{
				title: "Просьба о деньгах",
				minutes: 14,
				about: "Голосовое и даже видео можно обсудить отдельно. Сначала звонок по старому номеру или вопрос, ответ на который знает только этот человек."
			},
			{
				title: "Что видно посторонним",
				minutes: 16,
				about: "Телефон в профиле, геометки stories, открытый список друзей и старые фото документов в ленте."
			},
			{
				title: "Поддержка, которая пишет первой",
				minutes: 12,
				about: "Настоящая поддержка сервиса редко начинается с того, что вы должны назвать пароль в личном чате."
			}
		]
	},
	{
		slug: "pokupki",
		title: "Безопасные покупки и платежи в интернете",
		summary: "Как платить в знакомых приложениях, не вводить карту на странице из рекламы и что делать при спорной операции.",
		description: ["Большинство бытовых потерь выглядят как обычная оплата: страница похожа на магазин, сумма небольшая, курьер «уже у двери». Курс учит открывать платёж самим и читать, куда именно уходят реквизиты.", "Мы не говорим, что публичный Wi-Fi всегда «крадёт карту». Опаснее новая страница, которую вы открыли по чужой ссылке. Привычка важнее страха перед сетью кафе."],
		categoryId: "platezhi",
		level: "средний",
		hours: 4,
		price: 3400,
		format: "Бытовые сценарии покупок, доставки и переводов. Платёжная система к курсу не подключена.",
		popular: false,
		audience: "Тем, кто платит картой, через приложения банков и на маркетплейсах.",
		outcomes: [
			"Открываете магазин и банк сами, а не с баннера.",
			"Замечаете подмену страницы оплаты в учебном разборе.",
			"Знаете первый шаг при непонятном списании: банк по номеру с карты, не по номеру из SMS."
		],
		skills: [
			"платёжные страницы",
			"переводы",
			"доставка",
			"спорные списания"
		],
		lessons: [
			{
				title: "Свой путь к магазину",
				minutes: 14,
				about: "Закладка, приложение или адрес, который вы набрали. Реклама и письмо — повод проверить, а не готовая дверь."
			},
			{
				title: "Страница оплаты",
				minutes: 16,
				about: "Адрес, название получателя, лишние поля вроде паспорта и «кода из SMS для отмены». Учебные макеты, без настоящих платёжных форм."
			},
			{
				title: "Доставка и доплата",
				minutes: 14,
				about: "Пошлина, перевес, повторная оплата. Сверяем заказ там, где вы его создавали."
			},
			{
				title: "Перевод человеку",
				minutes: 12,
				about: "Телефон получателя легко перепутать специально. Крупная сумма заслуживает паузы и второго канала."
			},
			{
				title: "Непонятное списание",
				minutes: 14,
				about: "Не звоним по номеру из тревожного SMS. Открываем приложение банка или номер на самой карте. Сохраняем время и сумму."
			}
		]
	},
	{
		slug: "gigiena",
		title: "Цифровая гигиена и защита устройств",
		summary: "Телефон и компьютер как связка ключей: блокировка, обновления, приложения и резервный способ не потерять доступ.",
		description: ["Устройство, которое разблокировано «потому что я дома», часто и есть вся безопасность почты и банка. Курс собирает гигиену без десятков «оптимизаторов» из рекламы.", "Обновления здесь не ритуал ради галочки. Это способ закрывать уже известные дыры, пока вы занимаетесь своими делами."],
		categoryId: "ustroystva",
		level: "средний",
		hours: 5,
		price: 4700,
		format: "Практический порядок для телефона и ноутбука. Отдельное защитное ПО покупать не требуется.",
		popular: false,
		audience: "Тем, кто хочет привести телефон в порядок и не ставит всё подряд.",
		outcomes: [
			"Включаете блокировку экрана и понимаете, зачем она дома тоже.",
			"Обновляете систему и убираете лишние разрешения.",
			"Не ставите программы из случайных файлов и «очистителей» с баннера."
		],
		skills: [
			"блокировка экрана",
			"обновления",
			"разрешения",
			"резервный доступ"
		],
		lessons: [
			{
				title: "Экран, который запирается",
				minutes: 12,
				about: "Код или биометрия плюс короткий автозамок. Биометрия удобна, код нужен как запасной ключ."
			},
			{
				title: "Обновления без геройства",
				minutes: 14,
				about: "Система и браузер. Почему «напомнить завтра» на месяцы — уже решение, просто незаметное."
			},
			{
				title: "Откуда ставятся программы",
				minutes: 16,
				about: "Магазин приложений против файла из чата. Очистители, которые обещают ускорить телефон, часто просят слишком много."
			},
			{
				title: "Браузер и сохранённые входы",
				minutes: 14,
				about: "Чужой компьютер, общие планшеты и галочка «запомнить меня»."
			},
			{
				title: "Если телефон потерялся",
				minutes: 16,
				about: "Что можно сделать из другого устройства: найти, заблокировать, выйти из важных сервисов. Готовим это до потери, а не в панике."
			}
		]
	},
	{
		slug: "ii",
		title: "Безопасное использование искусственного интеллекта",
		summary: "Что можно отдавать чату, чего нельзя, и почему уверенный ответ бота не делает письмо или звонок настоящими.",
		description: ["Чаты с ИИ полезны для черновиков, объяснений и учебы. Они плохо подходят как сейф для паспорта, паролей, медицинских карт и чужой переписки. Курс проводит границу на бытовых примерах.", "Вторая часть — про входящие сообщения. Грамотный текст больше не признак живого сотрудника. Спокойная проверка отправителя важнее, чем поиск опечаток."],
		categoryId: "ii",
		level: "средний",
		hours: 3.5,
		price: 4500,
		format: "Короткие сценарии: что вставлять в чат, как проверять ответ и как относиться к «идеальным» письмам.",
		popular: false,
		audience: "Тем, кто уже пользуется чатами с ИИ на работе или дома.",
		outcomes: [
			"Не загружаете документы, которые нельзя показать постороннему сервису.",
			"Убираете из запроса чужие персональные данные и любые коды.",
			"Не путаете гладкий текст и голос с доказательством, что вам пишет банк или родственник."
		],
		skills: [
			"границы запроса",
			"проверка ответа",
			"поддельный текст",
			"глубокие подделки голоса"
		],
		lessons: [
			{
				title: "Чат — не закрытый дневник",
				minutes: 14,
				about: "Даже если интерфейс выглядит личным, вы отдаёте текст сервису. Пароли, коды и сканы документов туда не относятся."
			},
			{
				title: "Чужие данные в запросе",
				minutes: 12,
				about: "Договор можно обсуждать, только если вам это разрешено. Имена, телефоны и адреса других людей лучше вычистить."
			},
			{
				title: "Уверенная ошибка",
				minutes: 14,
				about: "Модель может гладко выдумать пункт закона или инструкцию. Важные шаги сверяем с документом и официальной страницей."
			},
			{
				title: "Письмо без ошибок",
				minutes: 12,
				about: "Раньше опечатки были подсказкой. Теперь их может не быть. Смотрим на просьбу и канал, а не на грамотность."
			},
			{
				title: "Звонок знакомым голосом",
				minutes: 14,
				about: "Если вас торопят перевести деньги, завершите разговор и перезвоните по номеру, который у вас уже был. Голос — слабое доказательство."
			}
		]
	}
];
function getCourse(slug) {
	return courses.find((course) => course.slug === slug);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/articles-B5RTD47J.js
var articles = [
	{
		slug: "pered-ssylkoj",
		title: "Чек-лист перед тем, как перейти по ссылке",
		kind: "Чек-лист",
		minutes: 6,
		lead: "Ссылка в письме — это чужая дверь. Прежде чем её открывать, можно за минуту ответить на несколько вопросов. Если хотя бы на один ответ «не знаю», спокойнее открыть сервис самим.",
		sections: [{
			heading: "Пять вопросов",
			paragraphs: ["Их не нужно заучивать как инструкцию пилота. Это одна и та же привычка: понять, кто просит и можно ли обойтись без его двери."],
			bullets: [
				"Я ждал это сообщение или сам начинал этот заказ, платёж, регистрацию?",
				"Адрес похож на сервис, которым я пользуюсь, если смотреть на каждую букву, а не на логотип?",
				"Меня торопят коротким сроком или пугают блокировкой?",
				"Просят пароль, код из SMS, фото карты или документа?",
				"Я могу сделать то же действие из приложения или закладки, не трогая эту ссылку?"
			]
		}, {
			heading: "Если сомневаетесь",
			paragraphs: ["Не пересылайте ссылку «на всякий случай» в семейный чат: так чужая дверь размножается. Откройте банк, магазин или почту так, как открываете их обычно. Если речь о деньгах, номер для звонка берите с карты или из официального приложения, а не из самого сообщения.", "Учебные примеры на этом сайте используют вымышленные имена и домен .example. Он зарезервирован для документации и не является живой схемой. Всё равно не стоит превращать любую учебную строку в адрес, по которому вы переходите."]
		}],
		sources: [{
			label: "NCSC: phishing scams",
			href: "https://www.ncsc.gov.uk/collection/phishing-scams"
		}, {
			label: "Информационная безопасность Банка России",
			href: "https://www.cbr.ru/information_security/"
		}]
	},
	{
		slug: "razbor-fishinga",
		title: "Разбор: посылка, пошлина и два часа на оплату",
		kind: "Разбор",
		minutes: 8,
		lead: "Один из самых бытовых сюжетов — сообщение о доставке. Ниже вымышленный текст. Он собран из повторяющихся приёмов, а не из реальной переписки.",
		sections: [
			{
				heading: "Текст, как он мог бы выглядеть",
				paragraphs: ["«СеверПост: посылка задержана. Оплатите сбор 49 ₽ в течение 2 часов, иначе отправление вернётся. Подтвердите адрес и данные карты на странице severpost-pay.example».", "Имени службы, которой вы пользуетесь, здесь нет нарочно. Подставить знакомый бренд в такое учебное сообщение было бы легко, и именно поэтому логотип ничего не доказывает."]
			},
			{
				heading: "Из чего собрано давление",
				paragraphs: ["В коротком тексте сразу несколько рычагов. По отдельности они бывают и в настоящих письмах, вместе и вперемешку с просьбой о карте — это уже повод остановиться."],
				bullets: [
					"Чужой или слишком новый адрес. Здесь это .example — специально нерабочая для таких историй зона.",
					"Короткий срок. Два часа нужны, чтобы вы не сверили заказ в спокойном приложении.",
					"Маленькая сумма. 49 рублей кажутся дешевле, чем минута сомнения.",
					"Просьба ввести карту на странице из сообщения, а не в приложении, где заказ уже есть."
				]
			},
			{
				heading: "Что делать вместо перехода",
				paragraphs: ["Откройте приложение или сайт службы, где заказ действительно оформляли, и посмотрите статус там. Если заказа не было, сообщение можно не «раскрывать» дальше. Если деньги уже ушли, звоните в свой банк по номеру с карты и опишите сумму и время. Номер из подозрительного SMS для этого не годится."]
			}
		],
		sources: [{
			label: "ФинЦЕРТ Банка России",
			href: "https://www.cbr.ru/information_security/fincert/"
		}, {
			label: "NCSC: phishing scams",
			href: "https://www.ncsc.gov.uk/collection/phishing-scams"
		}]
	},
	{
		slug: "paroli-i-kody",
		title: "Пароли и коды: что хранить, а что не отправлять",
		kind: "Инструкция",
		minutes: 7,
		lead: "Надёжность пароля — это не кроссворд из символов. Важнее длина, уникальность и то, что код подтверждения вы никому не диктуете.",
		sections: [{
			heading: "Рабочая стратегия",
			paragraphs: ["Рекомендации NIST по цифровым идентичностям (серия SP 800-63, актуальная редакция 800-63-4) описывают аутентификацию для серьёзных систем. Для домашней жизни из них полезно взять направление, а не превращать документ в бытовой закон: длинный уникальный секрет лучше короткого «сложного», а заставлять менять пароль по календарю не нужно, если его не раскрыли."],
			bullets: [
				"Отдельный пароль на почту, банк и магазины, где привязана карта.",
				"Менеджер паролей, если уникальных сочетаний стало больше, чем вы помните.",
				"Второй фактор на почте и в банке. Код из приложения обычно устойчивее SMS, но SMS лучше, чем ничего.",
				"Запасные коды восстановления не хранить в том чате, где их могут попросить «срочно переслать»."
			]
		}, {
			heading: "Что не отправляют никогда",
			paragraphs: ["Эти вещи не становятся безопаснее, если собеседник представляется поддержкой, ребёнком или работодателем."],
			bullets: [
				"Пароль целиком.",
				"Код из SMS или приложения, который только что пришёл вам.",
				"Полный номер карты вместе со сроком и кодом с оборота.",
				"Фото паспорта «для сверки личности» незнакомому чату."
			]
		}],
		sources: [{
			label: "NIST SP 800-63-4",
			href: "https://pages.nist.gov/800-63-4/"
		}, {
			label: "Публикация NIST SP 800-63-4",
			href: "https://www.nist.gov/publications/nist-sp-800-63-4-digital-identity-guidelines"
		}]
	},
	{
		slug: "pokupki-bez-speshki",
		title: "Покупки без спешки: страница оплаты и спорное списание",
		kind: "Инструкция",
		minutes: 7,
		lead: "Безопасная покупка чаще всего выглядит скучно: вы сами открыли знакомый магазин, увидели свой заказ и подтвердили оплату привычным способом.",
		sections: [{
			heading: "Перед оплатой",
			paragraphs: ["Публичная сеть в кафе — не главный злодей. Главный риск — страница, адрес которой выбрали не вы."],
			bullets: [
				"Наберите магазин сами или откройте его приложение.",
				"Проверьте сумму, название получателя и что у вас не просят лишние документы.",
				"Не диктуйте код из банка человеку, который «помогает провести платёж».",
				"Крупный перевод незнакомому получателю заслуживает паузы и проверки по другому каналу."
			]
		}, {
			heading: "Если списание непонятное",
			paragraphs: ["Откройте приложение банка привычным значком, не по ссылке из тревожного сообщения. Если приложения нет под рукой, звоните по номеру на карте. Запишите сумму, время и магазин, как он назван в операции. Дальше банк подскажет, как оспорить перевод: это уже их процедура, и она зависит от типа платежа.", "Сообщение «мы из безопасности, назовите код, чтобы отменить списание» — повод закончить разговор. Код как раз может подтвердить перевод, а не отмену."]
		}],
		sources: [{
			label: "Информационная безопасность Банка России",
			href: "https://www.cbr.ru/information_security/"
		}]
	},
	{
		slug: "ii-i-lichnoe",
		title: "Чаты с ИИ и личные данные",
		kind: "Инструкция",
		minutes: 6,
		lead: "ИИ хорошо ускоряет черновик и плохо заменяет сейф. Гладкий ответ также не доказывает, что входящее письмо написал живой сотрудник банка.",
		sections: [{
			heading: "Что не кладут в запрос",
			paragraphs: ["Если текст нельзя отправить малознакомому подрядчику, его не стоит вставлять и в чат."],
			bullets: [
				"Пароли, коды, ключи, резервные фразы.",
				"Сканы паспорта, полиса, карт и медицинские заключения.",
				"Чужая переписка и персональные данные других людей без права ими делиться.",
				"Рабочие документы, если договор или правила компании это запрещают."
			]
		}, {
			heading: "Как читать ответ и входящие письма",
			paragraphs: ["Модель может уверенно ошибиться в сроке, статье закона или шаге инструкции. Для решений о деньгах и документах откройте первоисточник. Для писем, которые пришли вам, грамотность текста больше не подсказка: смотрите, что у вас просят и можно ли сделать это из официального приложения.", "Если звонящий звучит как родственник и торопит с переводом, завершите разговор и перезвоните по номеру, который у вас уже был. Голос — слабое доказательство."]
		}],
		sources: [{
			label: "NCSC: phishing scams",
			href: "https://www.ncsc.gov.uk/collection/phishing-scams"
		}]
	}
];
var articleKinds = [
	"Все",
	"Чек-лист",
	"Разбор",
	"Инструкция"
];
function getArticle(slug) {
	return articles.find((article) => article.slug === slug);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-fAyq4BGp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Button({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("btn", `btn-${variant}`, className),
		...props
	});
}
function ButtonLink({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		className: cn("btn", `btn-${variant}`, className),
		...props
	});
}
function Container({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mx-auto w-full max-w-6xl px-4 sm:px-6", className),
		children
	});
}
function SectionLabel({ index, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mb-4 flex items-center gap-3 text-sm text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "display text-base text-accent",
				children: index
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "h-px w-8 bg-line",
				"aria-hidden": true
			}),
			children
		]
	});
}
function Logo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-7 place-items-center rounded-full bg-accent text-sm font-semibold text-accent-fg",
			"aria-hidden": true,
			children: "И"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "display text-xl text-fg",
			children: "Интервал"
		})]
	});
}
function DemoBanner({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "rounded-2xl border border-line bg-surface-2 px-4 py-3 text-sm leading-relaxed text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium text-fg",
			children: "Демонстрационный режим. "
		}), children]
	});
}
function Meter({ value, max, label }) {
	const pct = max === 0 ? 0 : Math.round(value / max * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-baseline justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-muted",
			children: [
				value,
				" из ",
				max
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-surface-2",
		role: "progressbar",
		"aria-valuenow": value,
		"aria-valuemin": 0,
		"aria-valuemax": max,
		"aria-valuetext": `${pct} процентов`,
		"aria-label": label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "meter-fill",
			style: { width: `${pct}%` }
		})
	})] });
}
function Spinner() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "spinner",
		"aria-hidden": true
	});
}
var EMPTY = {
	enrolled: [],
	lessons: {},
	quiz: null
};
var PROGRESS_KEY = "interval-progress-v1";
var EVENT = "interval-progress";
function loadProgress() {
	if (typeof window === "undefined") return EMPTY;
	try {
		const raw = localStorage.getItem(PROGRESS_KEY);
		if (!raw) return EMPTY;
		const parsed = JSON.parse(raw);
		return {
			enrolled: Array.isArray(parsed.enrolled) ? parsed.enrolled.filter((x) => typeof x === "string") : [],
			lessons: parsed.lessons && typeof parsed.lessons === "object" ? parsed.lessons : {},
			quiz: parsed.quiz ?? null
		};
	} catch {
		return EMPTY;
	}
}
function saveProgress(next) {
	localStorage.setItem(PROGRESS_KEY, JSON.stringify(next));
	window.dispatchEvent(new CustomEvent(EVENT));
}
function useProgress() {
	const [state, setState] = (0, import_react.useState)(EMPTY);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const read = () => setState(loadProgress());
		read();
		setReady(true);
		window.addEventListener(EVENT, read);
		window.addEventListener("storage", read);
		return () => {
			window.removeEventListener(EVENT, read);
			window.removeEventListener("storage", read);
		};
	}, []);
	const update = (fn) => {
		const next = fn(loadProgress());
		saveProgress(next);
		setState(next);
	};
	return {
		state,
		ready,
		update
	};
}
var THEME_KEY = "interval-theme";
function applyTheme(next, persist) {
	const root = document.documentElement;
	root.classList.add("theme-animate");
	root.dataset.theme = next;
	root.style.colorScheme = next;
	if (persist) localStorage.setItem(THEME_KEY, next);
	window.setTimeout(() => root.classList.remove("theme-animate"), 340);
}
function toggleTheme() {
	applyTheme((document.documentElement.dataset.theme === "dark" ? "dark" : "light") === "dark" ? "light" : "dark", true);
}
var links = [
	{
		to: "/courses",
		label: "Курсы",
		exact: false
	},
	{
		to: "/check",
		label: "Проверка",
		exact: true
	},
	{
		to: "/materials",
		label: "Материалы",
		exact: false
	},
	{
		to: "/author",
		label: "Автор",
		exact: true
	},
	{
		to: "/faq",
		label: "Вопросы",
		exact: true
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { state, ready } = useProgress();
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => {
			if (localStorage.getItem("interval-theme")) return;
			applyTheme(mq.matches ? "dark" : "light", false);
		};
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "header-bar",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "skip-link",
				children: "К содержанию"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "flex items-center gap-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-label": "Интервал, на главную",
						className: "rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "ms-auto hidden items-center gap-4 md:flex",
						"aria-label": "Разделы",
						children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							activeOptions: { exact: link.exact },
							className: "nav-link",
							activeProps: { className: "nav-link is-active" },
							children: link.label
						}, link.to))
					}),
					ready && (state.quiz || state.enrolled.length > 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/check",
						className: "hidden text-sm text-muted lg:inline",
						children: [
							state.quiz ? `Тест ${state.quiz.correct}/${state.quiz.total}` : null,
							state.quiz && state.enrolled.length > 0 ? " · " : null,
							state.enrolled.length > 0 ? `записи ${state.enrolled.length}` : null
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-secondary btn-icon ms-auto md:ms-0",
						onClick: toggleTheme,
						"aria-label": "Сменить цветовую тему",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "grid size-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
								className: "theme-icon theme-icon-light size-5",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
								className: "theme-icon theme-icon-dark size-5",
								"aria-hidden": true
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary btn-icon md:hidden",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						onClick: () => setOpen((value) => !value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "grid size-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: cn("icon-swap size-5", open && "is-off"),
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
								className: cn("icon-swap size-5", !open && "is-off"),
								"aria-hidden": true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: open ? "Закрыть меню" : "Открыть меню"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "mobile-nav",
				className: cn("fold md:hidden", open && "open"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fold-inner",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
						className: "flex flex-col pb-4",
						children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							className: "nav-link border-t border-line",
							activeProps: { className: "nav-link is-active" },
							activeOptions: { exact: link.exact },
							children: link.label
						}, link.to))
					})
				})
			})
		]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-20 border-t border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-sm leading-relaxed text-muted",
					children: "Цифровая грамотность без паники. Курсы, проверка и формы на этом сайте работают как демонстрация: оплаты нет, сообщения никуда не отправляются."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Разделы"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "text-fg",
						children: link.label
					}) }, link.to))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Ориентиры, не реклама"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "prose-link",
							href: "https://www.cbr.ru/information_security/",
							target: "_blank",
							rel: "noreferrer",
							children: "Банк России: информационная безопасность"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "prose-link",
							href: "https://pages.nist.gov/800-63-4/",
							target: "_blank",
							rel: "noreferrer",
							children: "NIST SP 800-63-4"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "prose-link",
							href: "https://www.ncsc.gov.uk/collection/phishing-scams",
							target: "_blank",
							rel: "noreferrer",
							children: "NCSC: phishing scams"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
			className: "border-t border-line py-4 text-sm text-muted",
			children: "Иванко Сергей Романович — вымышленный автор демонстрационного проекта. Биография не является реальной."
		})]
	});
}
var styles_default = "/assets/styles-D8lnkEFf.css";
var THEME_BOOT = `(function(){try{var k="interval-theme";var t=localStorage.getItem(k);if(t!=="light"&&t!=="dark"){t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}var r=document.documentElement;r.dataset.theme=t;r.style.colorScheme=t;}catch(e){}})();`;
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Интервал — цифровая грамотность без паники" },
			{
				name: "description",
				content: "Учебная платформа о спокойной жизни в интернете: курсы, материалы и проверка киберграмотности. Цены и формы демонстрационные."
			},
			{
				name: "theme-color",
				content: "#1A1714"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,650&family=Outfit:wght@400;500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root,
	notFoundComponent: NotFound
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOT } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-screen flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "content",
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { style: {
					background: "var(--surface)",
					color: "var(--fg)",
					border: "1px solid var(--line)"
				} }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page-in mx-auto max-w-3xl px-4 py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-3 text-5xl text-fg",
				children: "Такой страницы нет"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-prose text-muted",
				children: "Ссылка могла устареть. Каталог курсов и проверка на месте."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
					to: "/courses",
					children: "К курсам"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "btn btn-secondary",
					children: "На главную"
				})]
			})
		]
	});
}
var $$splitComponentImporter$8 = () => import("./routes-CPmSoemv.mjs");
var Route$9 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var Route$8 = createFileRoute("/author")({
	head: () => ({ meta: [{ title: "Автор — Интервал" }, {
		name: "description",
		content: "Иванко Сергей Романович — вымышленный автор демонстрационной платформы «Интервал»."
	}] }),
	component: AuthorPage
});
var story = [
	{
		t: "Наблюдение",
		d: "В сценарии проекта Сергей замечает, что близкие теряют деньги не из-за сложного взлома, а из-за спешки: мелкий сбор, чужая ссылка, код «для банка»."
	},
	{
		t: "Короткие объяснения",
		d: "Он начинает писать разборы на бытовом языке. Без процентов «по исследованию» и без обещания, что одна привычка закрывает все схемы."
	},
	{
		t: "Пауза как название",
		d: "Платформа получает имя «Интервал»: промежуток между сообщением и действием. Курсы — это те же объяснения, только разложенные по урокам."
	}
];
function AuthorPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-12 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoBanner, { children: "Иванко Сергей Романович — вымышленный персонаж. У него нет реальной биографии, дипломов, лицензий, места работы и проверяемых достижений. Не ищите этого человека как эксперта вне сайта." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-muted",
					children: "Автор сценария"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl",
					children: "Сергей Романович Иванко"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-10 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-prose space-y-4 leading-relaxed",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "В демонстрации он методист по цифровой безопасности для людей без технической профессии. Его задача на платформе — переводить почту, платежи, мессенджеры и чаты с ИИ на язык обычного дня." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Голос спокойный нарочно. Запугивание плохо учит: человек либо отмахивается, либо начинает бояться любого письма. Интервал предлагает другой ход — паузу и проверку источника." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Если где-то на странице звучит личная формула, это учебная реплика персонажа. Её нельзя цитировать как слова живого специалиста." })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "rounded-3xl bg-band px-6 py-6 text-band-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-band-muted",
							children: "Миссия внутри сценария"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display mt-3 text-3xl",
							children: "Чтобы полезная сеть не требовала постоянной тревоги."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-16 text-4xl",
					children: "Как в демо появился проект"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 border-t border-line",
					children: story.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-3 border-b border-line py-6 md:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display text-3xl text-accent md:col-span-3",
							children: String(index + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-9",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl",
								children: item.t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-prose text-muted",
								children: item.d
							})]
						})]
					}, item.t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-prose text-sm text-muted",
					children: "Это демонстрационный сюжет интерфейса, а не история реальной компании."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
						to: "/courses",
						children: "Смотреть курсы"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
						to: "/check",
						variant: "secondary",
						children: "Пройти проверку"
					})]
				})
			]
		})
	});
}
var $$splitComponentImporter$7 = () => import("./check-oWWXFluI.mjs");
var Route$7 = createFileRoute("/check")({
	head: () => ({ meta: [{ title: "Проверка — Интервал" }, {
		name: "description",
		content: "Учебный тест по бытовой киберграмотности с пояснением после каждого ответа."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./courses-CpxS_IJr.mjs");
var Route$6 = createFileRoute("/courses")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./faq-6FGHEgZC.mjs");
var Route$5 = createFileRoute("/faq")({
	head: () => ({ meta: [{ title: "Вопросы и контакт — Интервал" }, {
		name: "description",
		content: "Частые вопросы о демонстрационной платформе и локальная контактная форма."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./materials-15PAgJbf.mjs");
var Route$4 = createFileRoute("/materials")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./courses.index-BxsVqcMO.mjs");
var Route$3 = createFileRoute("/courses/")({
	head: () => ({ meta: [{ title: "Курсы — Интервал" }, {
		name: "description",
		content: "Демонстрационный каталог курсов по киберграмотности: поиск, уровень, тема и цена."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./courses._slug-CafCab0W.mjs");
var Route$2 = createFileRoute("/courses/$slug")({
	loader: ({ params }) => {
		const course = getCourse(params.slug);
		if (!course) throw notFound();
		return { course };
	},
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.course.title} — Интервал` : "Курс — Интервал" }, {
		name: "description",
		content: loaderData?.course.summary ?? "Страница курса"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./materials.index-clxRoDLF.mjs");
var Route$1 = createFileRoute("/materials/")({
	head: () => ({ meta: [{ title: "Материалы — Интервал" }, {
		name: "description",
		content: "Короткие инструкции, чек-листы и разборы типичных интернет-ситуаций."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./materials._slug-Dqedo6pQ.mjs");
var Route = createFileRoute("/materials/$slug")({
	loader: ({ params }) => {
		const article = getArticle(params.slug);
		if (!article) throw notFound();
		return { article };
	},
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.article.title} — Интервал` : "Материал — Интервал" }, {
		name: "description",
		content: loaderData?.article.lead ?? "Учебный материал"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AuthorRoute = Route$8.update({
	id: "/author",
	path: "/author",
	getParentRoute: () => Route$10
});
var CheckRoute = Route$7.update({
	id: "/check",
	path: "/check",
	getParentRoute: () => Route$10
});
var CoursesRoute = Route$6.update({
	id: "/courses",
	path: "/courses",
	getParentRoute: () => Route$10
});
var FaqRoute = Route$5.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$10
});
var MaterialsRoute = Route$4.update({
	id: "/materials",
	path: "/materials",
	getParentRoute: () => Route$10
});
var CoursesIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => CoursesRoute
});
var CoursesSlugRoute = Route$2.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => CoursesRoute
});
var MaterialsIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => MaterialsRoute
});
var MaterialsSlugRoute = Route.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => MaterialsRoute
});
var CoursesRouteChildren = {
	CoursesSlugRoute,
	CoursesIndexRoute
};
var CoursesRouteWithChildren = CoursesRoute._addFileChildren(CoursesRouteChildren);
var MaterialsRouteChildren = {
	MaterialsSlugRoute,
	MaterialsIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthorRoute,
	CheckRoute,
	CoursesRoute: CoursesRouteWithChildren,
	FaqRoute,
	MaterialsRoute: MaterialsRoute._addFileChildren(MaterialsRouteChildren)
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { courses as _, Button as a, DemoBanner as c, Spinner as d, cn as f, categoryLabel as g, categories as h, useProgress as i, Meter as l, articles as m, Route as n, ButtonLink as o, articleKinds as p, Route$2 as r, Container as s, router_exports as t, SectionLabel as u, getCourse as v };
