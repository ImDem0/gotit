import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as courses, f as cn, i as useProgress, m as articles, o as ButtonLink, s as Container, u as SectionLabel } from "./router-fAyq4BGp.mjs";
import { t as CourseRow } from "./course-row-0-RJT9Fd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CPmSoemv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var suspicious = {
	title: "Подозрительный вариант",
	from: "доставка@severpost-pay.example",
	body: "Посылка задержана. Оплатите сбор 49 ₽ в течение 2 часов, иначе отправление вернётся. Подтвердите адрес и данные карты на странице из этого сообщения.",
	points: [
		{
			id: "domain",
			label: "Адрес",
			text: "Домен .example зарезервирован для учебников и здесь стоит нарочно. В жизни смотрите не на имя службы в шапке, а на адрес целиком. Учебную строку всё равно не нужно открывать."
		},
		{
			id: "rush",
			label: "Два часа",
			text: "Короткий срок не даёт сверить заказ в спокойном приложении. Настоящая доставка обычно подождёт, пока вы откроете её сами."
		},
		{
			id: "sum",
			label: "49 ₽",
			text: "Маленькая сумма снижает сопротивление. Для схемы важнее, чтобы вы вообще ввели карту, а не размер «пошлины»."
		},
		{
			id: "card",
			label: "Карта",
			text: "Данные карты не подтверждают доставку. Их просят там, где платёж хотите начать не вы."
		}
	]
};
var calm = {
	title: "Спокойный вариант",
	from: "уведомление магазина, где вы сами покупали",
	body: "Заказ готов к выдаче. Код получения лежит в приложении магазина — в письме его нет. Ничего доплачивать не нужно, ссылка для оплаты не требуется.",
	points: [
		{
			id: "memory",
			label: "Свой заказ",
			text: "Сообщение совпадает с покупкой, которую вы помните. Это не доказательство само по себе, но уже другой тон ситуации."
		},
		{
			id: "nocard",
			label: "Без доплаты",
			text: "Вас не ведут на новую оплату. Если доплата всё же нужна, её ищут в том же заказе, а не на случайной странице."
		},
		{
			id: "code",
			label: "Код не в письме",
			text: "Секрет получения остаётся в приложении. Письмо, которое само приносит и код, и просьбу о карте, заслуживает паузы."
		},
		{
			id: "self",
			label: "Свой вход",
			text: "Дальше вы открываете магазин так, как обычно: значок приложения или закладка, не адрес из текста."
		}
	]
};
function MessageLab() {
	const [mode, setMode] = (0, import_react.useState)("suspicious");
	const [active, setActive] = (0, import_react.useState)("domain");
	const pack = mode === "suspicious" ? suspicious : calm;
	const current = pack.points.find((point) => point.id === active) ?? pack.points[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			role: "group",
			"aria-label": "Тип сообщения",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "chip",
				"aria-pressed": mode === "suspicious",
				onClick: () => {
					setMode("suspicious");
					setActive(suspicious.points[0].id);
				},
				children: "Подозрительное"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "chip",
				"aria-pressed": mode === "calm",
				onClick: () => {
					setMode("calm");
					setActive(calm.points[0].id);
				},
				children: "Спокойное"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mt-4 rounded-3xl border border-line bg-surface p-5",
			"aria-label": pack.title,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: pack.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: ["От: ", pack.from]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "sample mt-3 text-lg leading-relaxed text-fg",
					children: pack.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Это учебный текст. Ссылки внутри нет, переходить некуда."
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Нажмите на признак — разберём, почему он важен."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: pack.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": active === point.id,
					onClick: () => setActive(point.id),
					children: point.label
				}, point.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mt-4 rounded-3xl border border-line bg-accent-soft p-5"),
				"aria-live": "polite",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-2xl text-fg",
					children: current.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 leading-relaxed text-fg",
					children: current.text
				})]
			})
		] })]
	});
}
function Reveal({ children, className }) {
	const ref = (0, import_react.useRef)(null);
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setOn(true);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				setOn(true);
				observer.disconnect();
			}
		}, { threshold: .16 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("reveal", on && "reveal-in", className),
		children
	});
}
var nodes = [
	{
		id: "mask",
		kicker: "01",
		title: "Костюм",
		chip: "Имя службы",
		text: "Письмо надевает чужое или выдуманное имя. Логотип и грамотный текст копируются легко — это не доказательство."
	},
	{
		id: "rush",
		kicker: "02",
		title: "Спешка",
		chip: "2 часа · 49 ₽",
		text: "Короткий срок и маленькая сумма нужны, чтобы пауза показалась дороже, чем риск. Именно здесь стоит замедлиться."
	},
	{
		id: "exit",
		kicker: "03",
		title: "Увод",
		chip: "Чужая форма",
		text: "Дальше просят карту или код на странице, которую открыли не вы. Спокойный путь — своё приложение, а не ссылка из письма."
	}
];
function Scheme() {
	const [active, setActive] = (0, import_react.useState)("rush");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "drift drift-late rounded-3xl border border-line bg-surface p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Как устроена обычная схема"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 grid gap-3",
				children: nodes.map((node) => {
					const on = active === node.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": on,
						onClick: () => setActive(node.id),
						className: cn("flex w-full items-center gap-3 rounded-2xl border px-3 py-3 text-left transition-colors duration-200", on ? "border-accent bg-accent-soft" : "border-line bg-bg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("grid size-10 shrink-0 place-items-center rounded-full border border-line bg-surface text-sm", on && "pulse border-accent"),
							children: node.kicker
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-fg",
							children: node.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: node.chip
						})] })]
					}) }, node.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 min-h-16 text-sm leading-relaxed text-fg",
				"aria-live": "polite",
				children: nodes.find((node) => node.id === active)?.text
			})
		]
	});
}
var habits = [
	{
		title: "Пауза",
		text: "Срочная просьба о деньгах, коде или «подтверждении личности» почти всегда выигрывает у того, кто отвечает сразу. Десять секунд — уже навык."
	},
	{
		title: "Источник",
		text: "Сверяйте канал, а не тон. Логотип, грамотность и знакомое имя подделываются. Надёжнее открыть сервис самим."
	},
	{
		title: "Секрет",
		text: "Пароль, код из сообщения и данные карты не становятся безопаснее в переписке. Их не диктуют и не пересылают."
	},
	{
		title: "Устройство",
		text: "Телефон — связка ключей. Экран запирается, система обновляется, приложения не ставятся из случайного файла."
	}
];
var reasons = [
	{
		n: "01",
		title: "Сначала проверка",
		text: "Тест открыт без записи. Курс имеет смысл после того, как видно, где именно ответ разъехался."
	},
	{
		n: "02",
		title: "Без липовых цифр",
		text: "Мы не придумываем статистику потерь. Где опора внешняя, стоит ссылка на NIST, NCSC или Банк России."
	},
	{
		n: "03",
		title: "Учебные примеры",
		text: "Схемы разобраны на вымышленных текстах. Вредоносного кода и живых опасных адресов на сайте нет."
	},
	{
		n: "04",
		title: "Данные остаются у вас",
		text: "Прогресс и демо-запись живут в браузере. Общего аккаунта и скрытой отправки форм нет."
	}
];
function HomeView() {
	const [habit, setHabit] = (0, import_react.useState)(0);
	const { state, ready } = useProgress();
	const popular = courses.filter((course) => course.popular);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
				className: "grid items-end gap-10 py-12 md:py-20 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise text-sm text-muted",
						children: "Учебная платформа · не лицензированная школа"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "display rise rise-2 mt-4 text-4xl text-fg sm:text-6xl",
						children: "Останавливаться вовремя — тоже цифровой навык."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise rise-3 mt-6 max-w-prose text-lg leading-relaxed text-muted",
						children: "Интервал учит спокойно пользоваться интернетом: замечать мошенничество, беречь личные данные и не путать полезный сервис с ловушкой. Слоган простой — цифровая грамотность без паники."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise rise-4 mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/courses",
							children: "Смотреть курсы"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/check",
							variant: "secondary",
							children: "Проверить себя"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-sm text-muted",
						children: [courses.length, " курсов в демонстрационном каталоге · тест без регистрации"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scheme, {})]
			}),
			ready && (state.quiz || state.enrolled.length > 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
				className: "pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-line bg-surface px-5 py-4 text-sm text-muted",
					children: [
						"В этом браузере уже есть след учёбы.",
						state.quiz ? ` Тест: ${state.quiz.correct} из ${state.quiz.total}.` : "",
						state.enrolled.length ? ` Демо-записи: ${state.enrolled.length}.` : "",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/check",
							className: "prose-link",
							children: "Открыть проверку"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-line",
				"aria-labelledby": "habits-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-14 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "01",
							children: "Четыре привычки"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "habits-title",
							className: "display max-w-3xl text-4xl text-fg sm:text-5xl",
							children: "Защита цифровой личности начинается не с программы, а с повторяемого хода."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-3 sm:grid-cols-4",
							role: "tablist",
							"aria-label": "Привычки",
							children: habits.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								role: "tab",
								"aria-selected": habit === index,
								className: cn("rounded-2xl border px-4 py-4 text-left transition-colors duration-200", habit === index ? "border-accent bg-accent text-accent-fg" : "border-line bg-surface text-fg"),
								onClick: () => setHabit(index),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "display text-3xl",
									children: String(index + 1).padStart(2, "0")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block",
									children: item.title
								})]
							}, item.title))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-prose text-lg leading-relaxed",
							"aria-live": "polite",
							children: habits[habit]?.text
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-labelledby": "lab-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, {
					className: "py-14 md:py-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "02",
							children: "Учебный разбор"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "lab-title",
							className: "display max-w-3xl text-4xl text-fg sm:text-5xl",
							children: "Одно сообщение, два настроения"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-prose text-muted",
							children: "Сравните давление и спокойное уведомление. Ни одна строка не является настоящей ссылкой."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageLab, {})
						})
					] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-surface",
				"aria-labelledby": "courses-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-14 md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "03",
							children: "Курсы"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "courses-title",
							className: "display text-4xl text-fg sm:text-5xl",
							children: "С чего обычно начинают"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/courses",
							variant: "secondary",
							children: "Весь каталог"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: popular.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseRow, { course }, course.slug))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-labelledby": "reasons-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-14 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "04",
							children: "Как устроена платформа"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "reasons-title",
							className: "display max-w-3xl text-4xl text-fg sm:text-5xl",
							children: "Честно про то, что уже работает"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-10 grid gap-8 md:grid-cols-2",
							children: reasons.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-line pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
									className: "display text-3xl text-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-accent",
											children: item.n
										}),
										" ",
										item.title
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-2 max-w-prose text-muted",
									children: item.text
								})]
							}, item.n))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-line",
				"aria-labelledby": "author-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "grid gap-8 py-14 md:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)] md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "05",
							children: "Автор сценария"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "author-title",
							className: "display text-4xl text-fg sm:text-5xl",
							children: "Иванко Сергей Романович"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-prose text-lg leading-relaxed text-muted",
							children: "Вымышленный методист этого демо-проекта. Он нужен, чтобы у курсов был понятный голос: без запугивания и без поддельных регалий."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/author",
							variant: "secondary",
							className: "mt-6",
							children: "Как устроен этот персонаж"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "rounded-3xl bg-band px-6 py-6 text-band-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display text-3xl leading-tight",
							children: "«Если письмо торопит сильнее, чем ваш собственный день, это уже содержание, а не оформление.»"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
							className: "mt-4 text-sm text-band-muted",
							children: "Учебная фраза персонажа, не цитата реального человека."
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"aria-labelledby": "reads-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-14 md:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
							index: "06",
							children: "Материалы"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "reads-title",
							className: "display text-4xl text-fg",
							children: "Коротко, если курс пока не нужен"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 divide-y divide-line border-y border-line",
							children: articles.slice(0, 3).map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/materials/$slug",
								params: { slug: article.slug },
								className: "flex flex-wrap items-baseline justify-between gap-3 py-5 no-underline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-accent",
									children: article.kind
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xl text-fg",
									children: article.title
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [article.minutes, " мин"]
								})]
							}) }, article.slug))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-band text-band-fg",
				"aria-labelledby": "close-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "py-16 md:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "close-title",
						className: "display max-w-3xl text-4xl sm:text-6xl",
						children: "Десять минут на проверку скажут больше, чем ещё один тревожный заголовок."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/check",
							variant: "band",
							children: "Пройти проверку"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
							to: "/courses",
							variant: "on-band",
							children: "Выбрать курс"
						})]
					})]
				})
			})
		]
	});
}
var SplitComponent = HomeView;
//#endregion
export { SplitComponent as component };
