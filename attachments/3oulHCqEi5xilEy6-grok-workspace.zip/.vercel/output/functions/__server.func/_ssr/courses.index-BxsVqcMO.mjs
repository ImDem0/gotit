import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as categories, s as Container } from "./router-fAyq4BGp.mjs";
import { t as CourseRow } from "./course-row-0-RJT9Fd.mjs";
import { t as filterCourses } from "./catalog-DRie1qEJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses.index-BxsVqcMO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var prices = [
	{
		id: "all",
		label: "Любая цена"
	},
	{
		id: "low",
		label: "До 3 500 ₽"
	},
	{
		id: "mid",
		label: "3 500–4 500 ₽"
	},
	{
		id: "high",
		label: "Дороже 4 500 ₽"
	}
];
function CatalogPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [level, setLevel] = (0, import_react.useState)("all");
	const [price, setPrice] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("recommended");
	const result = (0, import_react.useMemo)(() => filterCourses({
		q,
		category,
		level,
		price,
		sort
	}), [
		q,
		category,
		level,
		price,
		sort
	]);
	const dirty = q !== "" || category !== "all" || level !== "all" || price !== "all" || sort !== "recommended";
	function reset() {
		setQ("");
		setCategory("all");
		setLevel("all");
		setPrice("all");
		setSort("recommended");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-12 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Каталог"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl",
					children: "Курсы, которые можно разобрать до записи"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-prose text-lg text-muted",
					children: "Цены демонстрационные. Поиск и фильтры работают сразу, без запроса на сервер."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-3 md:grid-cols-[minmax(0,1.4fr)_repeat(3,minmax(0,0.7fr))]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Поиск по названию"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: q,
								placeholder: "Название, навык или тема",
								onChange: (event) => setQ(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Уровень"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "select",
								value: level,
								onChange: (event) => setLevel(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "Любой уровень"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "начальный",
										children: "Начальный"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "средний",
										children: "Средний"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Цена"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "select",
								value: price,
								onChange: (event) => setPrice(event.target.value),
								children: prices.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.label
								}, item.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Сортировка"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "select",
								value: sort,
								onChange: (event) => setSort(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "recommended",
										children: "Сначала основные"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "price-asc",
										children: "Сначала дешевле"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "price-desc",
										children: "Сначала дороже"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "duration",
										children: "Сначала короче"
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2 overflow-x-auto pb-1",
					role: "group",
					"aria-label": "Тема курса",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip shrink-0",
						"aria-pressed": category === "all",
						onClick: () => setCategory("all"),
						children: "Все темы"
					}), categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip shrink-0",
						"aria-pressed": category === item.id,
						onClick: () => setCategory(item.id),
						children: item.label
					}, item.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-sm text-muted",
					"aria-live": "polite",
					children: [result.length === 0 ? "Ничего не нашлось" : `Показано: ${result.length}`, dirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ms-3 underline",
						onClick: reset,
						children: "Сбросить"
					}) : null]
				}),
				result.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-3xl border border-dashed border-line px-5 py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display text-3xl text-fg",
							children: "Пустой результат — тоже результат"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-prose text-muted",
							children: "По этому сочетанию фильтров курсов нет. Сбросьте условия или поищите короче: например, «парол» или «фишинг»."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary mt-5",
							onClick: reset,
							children: "Показать все курсы"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 border-t border-line",
					children: result.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseRow, { course }, course.slug))
				})
			]
		})
	});
}
//#endregion
export { CatalogPage as component };
