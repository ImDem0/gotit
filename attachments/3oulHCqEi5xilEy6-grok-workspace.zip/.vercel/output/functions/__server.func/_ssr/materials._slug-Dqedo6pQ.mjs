import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route, s as Container } from "./router-fAyq4BGp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/materials._slug-Dqedo6pQ.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const { article } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-12 md:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "text-sm text-muted",
				"aria-label": "Хлебные крошки",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/materials",
						className: "prose-link",
						children: "Материалы"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: " / "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: article.kind })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mt-6 max-w-prose",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-accent",
						children: [
							article.kind,
							" · ",
							article.minutes,
							" мин чтения"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "display mt-3 text-4xl text-fg sm:text-5xl",
						children: article.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-lg text-muted",
						children: article.lead
					}),
					article.sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display text-3xl",
								children: section.heading
							}),
							section.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed",
								children: paragraph
							}, paragraph)),
							section.bullets ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 list-disc space-y-2 ps-5 text-muted",
								children: section.bullets.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
							}) : null
						]
					}, section.heading)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-10 border-t border-line pt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg",
								children: "На что опирались"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-2",
								children: article.sources.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "prose-link",
									href: source.href,
									target: "_blank",
									rel: "noreferrer",
									children: source.label
								}) }, source.href))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted",
								children: "Ссылки ведут на сторонние сайты. «Интервал» их не контролирует и не превращает в юридическую консультацию."
							})
						]
					})
				]
			})]
		})
	});
}
//#endregion
export { ArticlePage as component };
