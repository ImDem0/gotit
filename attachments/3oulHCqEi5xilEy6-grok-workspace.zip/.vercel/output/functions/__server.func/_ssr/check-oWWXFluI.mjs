import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Button, f as cn, i as useProgress, l as Meter, o as ButtonLink, s as Container, v as getCourse } from "./router-fAyq4BGp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/check-oWWXFluI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var quizQuestions = [
	{
		id: "parcel",
		topic: "messages",
		topicLabel: "сообщения и фишинг",
		courseSlug: "fishing",
		prompt: "Вам пришло сообщение: «Посылка задержана. Оплатите сбор 49 ₽ в течение 2 часов: severpost-pay.example». Как поступить спокойнее?",
		context: "Пример вымышленный. Адрес специально на домене .example и никуда не ведёт.",
		options: [
			{
				id: "pay",
				label: "Оплатить маленькую сумму, чтобы не потерять посылку."
			},
			{
				id: "name",
				label: "Открыть ссылку и ввести только имя, без карты."
			},
			{
				id: "check",
				label: "Не открывать ссылку. Проверить заказ в приложении службы, которой вы реально пользуетесь, или у того, кто отправлял."
			},
			{
				id: "forward",
				label: "Переслать сообщение близким, чтобы они оплатили за вас."
			}
		],
		correctId: "check",
		explain: "Срок, мелкая сумма и чужой адрес вместе просят поторопиться. Надёжнее сверить заказ там, где вы его ждёте, а не на странице из сообщения. Даже «только имя» оставляет след и часто ведёт к следующему шагу с картой."
	},
	{
		id: "bank-mail",
		topic: "messages",
		topicLabel: "сообщения и фишинг",
		courseSlug: "fishing",
		prompt: "Письмо от support@your-bank.example просит срочно подтвердить пароль из-за «подозрительного входа». Что здесь важнее всего?",
		context: "Банк вымышленный, домен учебный.",
		options: [
			{
				id: "typos",
				label: "В письме нет опечаток, значит оно настоящее."
			},
			{
				id: "secret",
				label: "Просьба сообщить пароль или перейти по ссылке из письма, чтобы «подтвердить вход»."
			},
			{
				id: "logo",
				label: "В письме есть логотип, этого достаточно."
			},
			{
				id: "day",
				label: "Письмо пришло днём, ночью мошенники не пишут."
			}
		],
		correctId: "secret",
		explain: "Грамотность и логотип больше ничего не доказывают: текст легко сделать гладким. Важна просьба отдать секрет или воспользоваться чужой ссылкой. Вход лучше проверить, открыв приложение банка самостоятельно."
	},
	{
		id: "password",
		topic: "passwords",
		topicLabel: "пароли и коды",
		courseSlug: "paroli",
		prompt: "Какой подход к паролям спокойнее для обычной жизни? Свой настоящий пароль вводить не нужно.",
		options: [
			{
				id: "reuse",
				label: "Один сложный пароль вроде Password123! на почту, магазины и банк."
			},
			{
				id: "unique",
				label: "Длинные разные пароли, которые помнит менеджер, и второй фактор там, где он доступен."
			},
			{
				id: "birth",
				label: "Дата рождения и имя: так точно не забудется."
			},
			{
				id: "chat",
				label: "Записать пароль в избранное мессенджера, чтобы был под рукой."
			}
		],
		correctId: "unique",
		explain: "Сложность без уникальности слабая: одна утечка открывает остальные сервисы. Дата рождения слишком общедоступна. Переписка — не сейф. Направление рекомендаций NIST SP 800-63-4: длина и отдельность секрета важнее пёстрого короткого пароля и календарной смены «на всякий случай»."
	},
	{
		id: "code",
		topic: "social",
		topicLabel: "мессенджеры",
		courseSlug: "socseti",
		prompt: "В мессенджере знакомое имя пишет: «Я на совещании, пришли код, который только что пришёл тебе на телефон». Что делать?",
		options: [
			{
				id: "send",
				label: "Прислать код: это же знакомый человек."
			},
			{
				id: "photo",
				label: "Отправить фотографию кода, так «не считается текстом»."
			},
			{
				id: "refuse",
				label: "Не отправлять. Код такой же секрет, как пароль. Связаться другим способом, который начинаете вы."
			},
			{
				id: "story",
				label: "Опубликовать код в сторис, чтобы человек сам его увидел."
			}
		],
		correctId: "refuse",
		explain: "Код подтверждает действие того, на чей телефон он пришёл. Знакомое имя могло оказаться чужим доступом к аккаунту. Фото кода — это всё ещё код."
	},
	{
		id: "wifi",
		topic: "payments",
		topicLabel: "платежи",
		courseSlug: "pokupki",
		prompt: "В кафе с открытым Wi-Fi нужно оплатить покупку. Какой вариант разумнее?",
		options: [
			{
				id: "ad",
				label: "Ввести карту на новом сайте, который открылся из рекламы."
			},
			{
				id: "app",
				label: "Открыть официальное приложение или знакомый сайт, который вы набрали сами. Новая страница из объявления опаснее самого факта Wi-Fi."
			},
			{
				id: "tell",
				label: "Продиктовать номер карты и код из SMS человеку рядом, чтобы он «помог провести оплату»."
			},
			{
				id: "unlock",
				label: "Снять блокировку телефона насовсем, так платить быстрее."
			}
		],
		correctId: "app",
		explain: "Публичная сеть — повод не открывать случайные платёжные страницы, а не причина паниковать из-за привычного приложения. Код из банка и полный номер карты не диктуют помощникам."
	},
	{
		id: "quiz-app",
		topic: "data",
		topicLabel: "личные данные",
		courseSlug: "lichnye-dannye",
		prompt: "В социальной сети тест просит девичью фамилию матери, кличку первого питомца и школу. Как к этому отнестись?",
		options: [
			{
				id: "honest",
				label: "Ответить честно: это просто игра."
			},
			{
				id: "skip",
				label: "Пропустить или ответить невсерьёз. Так часто выглядят вопросы для восстановления доступа."
			},
			{
				id: "tag",
				label: "Ответить и отметить друзей, чтобы тест разошёлся."
			},
			{
				id: "passport",
				label: "Приложить фото паспорта, чтобы результат был точнее."
			}
		],
		correctId: "skip",
		explain: "Такие ответы помогают входить в аккаунты тем, кто их узнал. Игра не обязана получать настоящую биографию. Паспорт в тесте не нужен никогда."
	},
	{
		id: "phone",
		topic: "devices",
		topicLabel: "устройства",
		courseSlug: "gigiena",
		prompt: "Какая привычка полезнее для телефона?",
		options: [
			{
				id: "cleaner",
				label: "Поставить все «очистители» подряд из рекламных баннеров."
			},
			{
				id: "hygiene",
				label: "Обновлять систему, запирать экран кодом и не ставить приложения из случайных файлов в чатах."
			},
			{
				id: "nolock",
				label: "Отключить блокировку дома навсегда."
			},
			{
				id: "sms",
				label: "Пересылать скриншоты банковских SMS в незнакомый чат «поддержки»."
			}
		],
		correctId: "hygiene",
		explain: "Телефон часто и есть ключ от почты и банка. Обновления закрывают уже известные проблемы, а код на экране помогает, если аппарат оказался в чужих руках. Очиститель из рекламы нередко просит слишком широкие права."
	},
	{
		id: "ai",
		topic: "ai",
		topicLabel: "искусственный интеллект",
		courseSlug: "ii",
		prompt: "Хотите, чтобы чат с ИИ проверил договор, и думаете приложить скан паспорта «чтобы было понятно, кто вы». Как поступить?",
		options: [
			{
				id: "all",
				label: "Отправить всё: чат выглядит личным, почти как сейф."
			},
			{
				id: "careful",
				label: "Паспорт не загружать. Договор отправлять только если вам можно делиться им, убрав чужие персональные данные, пароли и коды."
			},
			{
				id: "comment",
				label: "Положить скан паспорта в публичный комментарий под ботом."
			},
			{
				id: "otp",
				label: "Попросить бота выдать одноразовый код для входа в банк."
			}
		],
		correctId: "careful",
		explain: "Чат — сервис, а не домашний сейф. Паспорт, пароли и коды туда не относятся. Чужие данные из договора тоже не стоит отдавать без нужды. Бот не выдаёт банковские коды, а просьба «прислать код» в любом канале — плохой знак."
	}
];
function levelCopy(correct, total) {
	const ratio = correct / total;
	if (ratio >= .85) return {
		title: "Спокойная бытовая практика",
		text: "Вы уверенно отличаете давление и просьбу о секрете от обычного сообщения. Имеет смысл лишь точечно углубить темы, если какая-то всё же сбилась."
	};
	if (ratio >= .5) return {
		title: "Ориентир уже есть",
		text: "База на месте. Ниже — темы, где ответ уехал в сторону. Их достаточно закрыть коротким курсом или материалом, без ощущения, что «вы ничего не знаете»."
	};
	return {
		title: "Хорошая точка старта",
		text: "Пробелы нормальны: схемы как раз рассчитывают на спешку, а не на незнание терминов. Начните с основ и с разбора сообщений — это быстрее всего окупается в обычной почте."
	};
}
function QuizView() {
	const { state, update } = useProgress();
	const [phase, setPhase] = (0, import_react.useState)("intro");
	const [index, setIndex] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [checked, setChecked] = (0, import_react.useState)(false);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const question = quizQuestions[index];
	const correctCount = quizQuestions.filter((item) => answers[item.id] === item.correctId).length;
	function begin() {
		setPhase("question");
		setIndex(0);
		setPicked(null);
		setChecked(false);
		setAnswers({});
	}
	function confirm() {
		if (!picked || !question) return;
		setChecked(true);
		setAnswers((prev) => ({
			...prev,
			[question.id]: picked
		}));
	}
	function next() {
		if (!question) return;
		if (index === quizQuestions.length - 1) {
			const finalAnswers = answers;
			const correct = quizQuestions.filter((item) => finalAnswers[item.id] === item.correctId).length;
			const missed = [...new Set(quizQuestions.filter((item) => finalAnswers[item.id] !== item.correctId).map((item) => item.courseSlug))];
			update((current) => ({
				...current,
				quiz: {
					correct,
					total: quizQuestions.length,
					missed,
					at: (/* @__PURE__ */ new Date()).toISOString()
				}
			}));
			setPhase("result");
			toast("Результат сохранён в этом браузере");
			return;
		}
		setIndex((value) => value + 1);
		setPicked(null);
		setChecked(false);
	}
	if (phase === "intro") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-prose",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "leading-relaxed text-muted",
				children: "Восемь бытовых ситуаций: письма, коды, пароли, платежи, устройство и чат с ИИ. Свои пароли и данные вводить не нужно. После выбора будет пояснение. Примеры вымышлены."
			}),
			state.quiz ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"Прошлый результат в этом браузере: ",
					state.quiz.correct,
					" из ",
					state.quiz.total,
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				className: "mt-6",
				onClick: begin,
				children: state.quiz ? "Пройти ещё раз" : "Начать проверку"
			})
		]
	});
	if (phase === "result") {
		const copy = levelCopy(correctCount, quizQuestions.length);
		const missedSlugs = [...new Set(quizQuestions.filter((item) => answers[item.id] !== item.correctId).map((item) => item.courseSlug))];
		const picks = missedSlugs.length ? missedSlugs : ["osnovy"];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
				value: correctCount,
				max: quizQuestions.length,
				label: "Верные ответы"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-8 text-4xl text-fg",
				children: copy.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-prose leading-relaxed text-muted",
				children: copy.text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-3",
				children: picks.map((slug) => {
					const course = getCourse(slug);
					if (!course) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/courses/$slug",
						params: { slug },
						className: "block rounded-2xl border border-line px-4 py-4 no-underline hover:bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: missedSlugs.length ? "Имеет смысл посмотреть" : "Если хотите систему, начните здесь"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-lg text-fg",
							children: course.title
						})]
					}, slug);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-10 text-lg",
				children: "Разбор ответов"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 space-y-4",
				children: quizQuestions.map((item, number) => {
					const ok = answers[item.id] === item.correctId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-line pb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									number + 1,
									". ",
									ok ? "Совпало" : "Есть более спокойный вариант"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-fg",
								children: item.prompt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: item.explain
							})
						]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				className: "mt-6",
				onClick: begin,
				children: "Пройти заново"
			})
		] });
	}
	if (!question) return null;
	const chosenCorrect = picked === question.correctId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
			value: index + (checked ? 1 : 0),
			max: quizQuestions.length,
			label: "Ход проверки"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-accent",
			children: question.topicLabel
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mt-2 text-3xl text-fg sm:text-4xl",
			children: question.prompt
		}),
		question.context ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: question.context
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3",
			role: "radiogroup",
			"aria-label": "Варианты",
			children: question.options.map((option) => {
				const selected = picked === option.id;
				const showCorrect = checked && option.id === question.correctId;
				const showWrong = checked && selected && !chosenCorrect;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "radio",
					"aria-checked": selected,
					disabled: checked,
					onClick: () => setPicked(option.id),
					className: cn("rounded-2xl border px-4 py-4 text-left transition-colors duration-200", showCorrect && "border-good bg-surface", showWrong && "border-danger bg-surface", !checked && selected && "border-accent bg-accent-soft", !checked && !selected && "border-line bg-surface hover:bg-surface-2", checked && !showCorrect && !showWrong && "border-line opacity-70"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: option.label
						}),
						showCorrect ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-sm text-good",
							children: "Верный для этой ситуации ответ"
						}) : null,
						showWrong ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-sm text-danger",
							children: "Ваш выбор"
						}) : null
					]
				}, option.id);
			})
		}),
		checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 rounded-2xl border border-line bg-surface-2 p-4",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: chosenCorrect ? "Да, так спокойнее." : "Здесь надёжнее другой ход."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 leading-relaxed",
				children: question.explain
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap gap-3",
			children: [!checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: !picked,
				onClick: confirm,
				children: "Пояснить ответ"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: next,
				children: index === quizQuestions.length - 1 ? "Показать результат" : "Дальше"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonLink, {
				to: "/courses",
				variant: "ghost",
				children: "К курсам"
			})]
		})
	] });
}
function CheckPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-12 md:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Проверка"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl",
					children: "Десять минут без настоящих секретов"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizView, {})
				})
			]
		})
	});
}
//#endregion
export { CheckPage as component };
