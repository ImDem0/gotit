import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { CourseRow } from "@/components/course-row";
import { EnrollPanel } from "@/components/enroll-panel";
import { Container } from "@/components/ui";
import { relatedCourses } from "@/lib/catalog";
import { categoryLabel, getCourse } from "@/lib/data/courses";
import { formatHours } from "@/lib/format";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/courses/$slug")({
  loader: ({ params }) => {
    const course = getCourse(params.slug);
    if (!course) throw notFound();
    return { course };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.course.title} — Интервал` : "Курс — Интервал" },
      { name: "description", content: loaderData?.course.summary ?? "Страница курса" },
    ],
  }),
  component: CoursePage,
});

function CoursePage() {
  const { course } = Route.useLoaderData();
  const related = relatedCourses(course.slug);
  const { state, update } = useProgress();
  const done = state.lessons[course.slug] ?? [];
  const [open, setOpen] = useState(0);

  function toggleLesson(index: number) {
    update((current) => {
      const prev = current.lessons[course.slug] ?? [];
      const next = prev.includes(index) ? prev.filter((item) => item !== index) : [...prev, index];
      return { ...current, lessons: { ...current.lessons, [course.slug]: next } };
    });
  }

  return (
    <main className="page-in">
      <Container className="py-10 md:py-14">
        <nav className="text-sm text-muted" aria-label="Хлебные крошки">
          <Link to="/courses" className="prose-link">
            Курсы
          </Link>
          <span aria-hidden> / </span>
          <span>{course.title}</span>
        </nav>
        <div className="mt-6 grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_20rem]">
          <header>
            <p className="text-sm text-accent">
              {categoryLabel(course.categoryId)} · {course.level} · {formatHours(course.hours)}
            </p>
            <h1 className="display mt-3 text-4xl text-fg sm:text-6xl">{course.title}</h1>
            <p className="mt-4 max-w-prose text-lg text-muted">{course.summary}</p>
          </header>
          <div className="lg:row-span-3">
            <EnrollPanel course={course} />
          </div>
          <div className="space-y-10">
            {course.description.map((paragraph) => (
              <p key={paragraph} className="max-w-prose leading-relaxed">
                {paragraph}
              </p>
            ))}
            <section>
              <h2 className="display text-3xl">Для кого</h2>
              <p className="mt-3 max-w-prose text-muted">{course.audience}</p>
            </section>
            <section>
              <h2 className="display text-3xl">Что останется после курса</h2>
              <ul className="mt-4 max-w-prose list-disc space-y-2 ps-5 text-muted">
                {course.outcomes.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </section>
            <section>
              <h2 className="display text-3xl">Навыки</h2>
              <ul className="mt-4 flex flex-wrap gap-2">
                {course.skills.map((skill) => (
                  <li key={skill} className="rounded-full border border-line px-3 py-2 text-sm">
                    {skill}
                  </li>
                ))}
              </ul>
            </section>
            <section>
              <h2 className="display text-3xl">Программа</h2>
              <p className="mt-3 max-w-prose text-sm text-muted">
                Отметка «урок пройден» хранится только в этом браузере и не требует записи.
              </p>
              <div className="mt-4 border-t border-line">
                {course.lessons.map((lesson, index) => {
                  const isOpen = open === index;
                  return (
                    <div key={lesson.title} className="border-b border-line">
                      <div className="flex items-start gap-3 py-3">
                        <label className="mt-3 flex items-center gap-2 text-sm text-muted">
                          <input
                            type="checkbox"
                            checked={done.includes(index)}
                            onChange={() => toggleLesson(index)}
                          />
                          <span className="sr-only">Урок пройден: {lesson.title}</span>
                        </label>
                        <button
                          type="button"
                          className="flex min-h-11 flex-1 items-center justify-between gap-3 text-left"
                          aria-expanded={isOpen}
                          onClick={() => setOpen(isOpen ? -1 : index)}
                        >
                          <span>
                            <span className="block text-fg">{lesson.title}</span>
                            <span className="text-sm text-muted">{lesson.minutes} мин</span>
                          </span>
                          <ChevronDown className={cn("size-5 shrink-0 transition-transform duration-200", isOpen && "rotate-180")} />
                        </button>
                      </div>
                      <div className={cn("fold", isOpen && "open")}>
                        <div className="fold-inner">
                          <p className="max-w-prose pb-4 ps-8 text-muted">{lesson.about}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
            <section className="rounded-3xl border border-line bg-surface-2 p-5">
              <h2 className="text-lg">Кто ведёт в этом сценарии</h2>
              <p className="mt-2 max-w-prose text-muted">
                Иванко Сергей Романович — вымышленный автор платформы. У курса нет реального преподавателя, диплома и лицензии.{" "}
                <Link to="/author" className="prose-link">
                  Читать оговорку
                </Link>
                .
              </p>
            </section>
          </div>
        </div>
        <section className="mt-16">
          <h2 className="display text-3xl">Рядом по смыслу</h2>
          <div className="mt-4 border-t border-line">
            {related.map((item) => (
              <CourseRow key={item.slug} course={item} />
            ))}
          </div>
        </section>
      </Container>
    </main>
  );
}
