import { createRootRoute, HeadContent, Link, Outlet, Scripts } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { ButtonLink } from "@/components/ui";
import appCss from "../styles.css?url";

const THEME_BOOT = `(function(){try{var k="interval-theme";var t=localStorage.getItem(k);if(t!=="light"&&t!=="dark"){t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}var r=document.documentElement;r.dataset.theme=t;r.style.colorScheme=t;}catch(e){}})();`;

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Интервал — цифровая грамотность без паники" },
      {
        name: "description",
        content:
          "Учебная платформа о спокойной жизни в интернете: курсы, материалы и проверка киберграмотности. Цены и формы демонстрационные.",
      },
      { name: "theme-color", content: "#1A1714" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,650&family=Outfit:wght@400;500;600&display=swap",
      },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: Root,
  notFoundComponent: NotFound,
});

function Root() {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOT }} />
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <div className="flex min-h-screen flex-col">
            <SiteHeader />
            <div id="content" className="flex-1">
              <Outlet />
            </div>
            <SiteFooter />
          </div>
          <Toaster
            position="top-center"
            toastOptions={{
              style: {
                background: "var(--surface)",
                color: "var(--fg)",
                border: "1px solid var(--line)",
              },
            }}
          />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  return (
    <main className="page-in mx-auto max-w-3xl px-4 py-24">
      <p className="text-sm text-muted">404</p>
      <h1 className="display mt-3 text-5xl text-fg">Такой страницы нет</h1>
      <p className="mt-4 max-w-prose text-muted">Ссылка могла устареть. Каталог курсов и проверка на месте.</p>
      <div className="mt-6 flex flex-wrap gap-3">
        <ButtonLink to="/courses">К курсам</ButtonLink>
        <Link to="/" className="btn btn-secondary">
          На главную
        </Link>
      </div>
    </main>
  );
}
