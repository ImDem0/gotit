import { createFileRoute } from "@tanstack/react-router";
import { ContactForm } from "@/components/contact-form";
import { FaqList } from "@/components/faq-list";
import { Container } from "@/components/ui";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "Вопросы и контакт — Интервал" },
      { name: "description", content: "Частые вопросы о демонстрационной платформе и локальная контактная форма." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  return (
    <main className="page-in">
      <Container className="grid gap-14 py-12 md:py-16 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
        <section>
          <p className="text-sm text-muted">Вопросы</p>
          <h1 className="display mt-3 text-4xl text-fg sm:text-5xl">Коротко о том, чего сайт не делает</h1>
          <div className="mt-8">
            <FaqList />
          </div>
        </section>
        <section>
          <h2 className="display text-4xl">Написать</h2>
          <p className="mt-3 text-muted">Форма для проверки полей. Живого ящика за ней нет.</p>
          <div className="mt-6">
            <ContactForm />
          </div>
        </section>
      </Container>
    </main>
  );
}
