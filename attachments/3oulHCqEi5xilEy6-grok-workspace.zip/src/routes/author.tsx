import { createFileRoute } from "@tanstack/react-router";
import { ButtonLink, Container, DemoBanner } from "@/components/ui";

export const Route = createFileRoute("/author")({
  head: () => ({
    meta: [
      { title: "Автор — Интервал" },
      {
        name: "description",
        content: "Иванко Сергей Романович — вымышленный автор демонстрационной платформы «Интервал».",
      },
    ],
  }),
  component: AuthorPage,
});

const story = [
  {
    t: "Наблюдение",
    d: "В сценарии проекта Сергей замечает, что близкие теряют деньги не из-за сложного взлома, а из-за спешки: мелкий сбор, чужая ссылка, код «для банка».",
  },
  {
    t: "Короткие объяснения",
    d: "Он начинает писать разборы на бытовом языке. Без процентов «по исследованию» и без обещания, что одна привычка закрывает все схемы.",
  },
  {
    t: "Пауза как название",
    d: "Платформа получает имя «Интервал»: промежуток между сообщением и действием. Курсы — это те же объяснения, только разложенные по урокам.",
  },
];

export function AuthorPage() {
  return (
    <main className="page-in">
      <Container className="py-12 md:py-16">
        <DemoBanner>
          Иванко Сергей Романович — вымышленный персонаж. У него нет реальной биографии, дипломов, лицензий, места работы и проверяемых достижений. Не ищите этого человека как эксперта вне сайта.
        </DemoBanner>
        <p className="mt-8 text-sm text-muted">Автор сценария</p>
        <h1 className="display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl">Сергей Романович Иванко</h1>
        <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
          <div className="max-w-prose space-y-4 leading-relaxed">
            <p>
              В демонстрации он методист по цифровой безопасности для людей без технической профессии. Его задача на платформе — переводить почту, платежи, мессенджеры и чаты с ИИ на язык обычного дня.
            </p>
            <p>
              Голос спокойный нарочно. Запугивание плохо учит: человек либо отмахивается, либо начинает бояться любого письма. Интервал предлагает другой ход — паузу и проверку источника.
            </p>
            <p>
              Если где-то на странице звучит личная формула, это учебная реплика персонажа. Её нельзя цитировать как слова живого специалиста.
            </p>
          </div>
          <aside className="rounded-3xl bg-band px-6 py-6 text-band-fg">
            <p className="text-sm text-band-muted">Миссия внутри сценария</p>
            <p className="display mt-3 text-3xl">Чтобы полезная сеть не требовала постоянной тревоги.</p>
          </aside>
        </div>
        <h2 className="display mt-16 text-4xl">Как в демо появился проект</h2>
        <ol className="mt-6 border-t border-line">
          {story.map((item, index) => (
            <li key={item.t} className="grid gap-3 border-b border-line py-6 md:grid-cols-12">
              <p className="display text-3xl text-accent md:col-span-3">{String(index + 1).padStart(2, "0")}</p>
              <div className="md:col-span-9">
                <h3 className="text-xl">{item.t}</h3>
                <p className="mt-2 max-w-prose text-muted">{item.d}</p>
              </div>
            </li>
          ))}
        </ol>
        <p className="mt-6 max-w-prose text-sm text-muted">
          Это демонстрационный сюжет интерфейса, а не история реальной компании.
        </p>
        <div className="mt-10 flex flex-wrap gap-3">
          <ButtonLink to="/courses">Смотреть курсы</ButtonLink>
          <ButtonLink to="/check" variant="secondary">
            Пройти проверку
          </ButtonLink>
        </div>
      </Container>
    </main>
  );
}
