import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Container } from "@/components/ui";
import { articleKinds, articles } from "@/lib/data/articles";

export const Route = createFileRoute("/materials/")({
  head: () => ({
    meta: [
      { title: "Материалы — Интервал" },
      { name: "description", content: "Короткие инструкции, чек-листы и разборы типичных интернет-ситуаций." },
    ],
  }),
  component: MaterialsPage,
});

function MaterialsPage() {
  const [kind, setKind] = useState<(typeof articleKinds)[number]>("Все");
  const list = articles.filter((article) => kind === "Все" || article.kind === kind);

  return (
    <main className="page-in">
      <Container className="py-12 md:py-16">
        <p className="text-sm text-muted">Читальня</p>
        <h1 className="display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl">Короткие материалы без записи на курс</h1>
        <p className="mt-4 max-w-prose text-lg text-muted">
          Чек-листы и разборы можно читать отдельно. Это не новости: приёмы общие, а детали схем меняются. Где есть опора, стоит ссылка.
        </p>
        <div className="mt-8 flex flex-wrap gap-2" role="group" aria-label="Тип материала">
          {articleKinds.map((item) => (
            <button key={item} type="button" className="chip" aria-pressed={kind === item} onClick={() => setKind(item)}>
              {item}
            </button>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted" aria-live="polite">
          {list.length === 0 ? "Таких материалов нет" : `Материалов: ${list.length}`}
        </p>
        <ul className="mt-2 border-t border-line">
          {list.map((article) => (
            <li key={article.slug} className="border-b border-line">
              <Link to="/materials/$slug" params={{ slug: article.slug }} className="grid gap-2 py-6 no-underline md:grid-cols-12">
                <span className="text-sm text-accent md:col-span-3">
                  {article.kind} · {article.minutes} мин
                </span>
                <span className="md:col-span-9">
                  <span className="display block text-3xl text-fg">{article.title}</span>
                  <span className="mt-2 block max-w-prose text-muted">{article.lead}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </Container>
    </main>
  );
}
