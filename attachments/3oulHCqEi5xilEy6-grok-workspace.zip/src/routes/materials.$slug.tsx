import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Container } from "@/components/ui";
import { getArticle } from "@/lib/data/articles";

export const Route = createFileRoute("/materials/$slug")({
  loader: ({ params }) => {
    const article = getArticle(params.slug);
    if (!article) throw notFound();
    return { article };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.article.title} — Интервал` : "Материал — Интервал" },
      { name: "description", content: loaderData?.article.lead ?? "Учебный материал" },
    ],
  }),
  component: ArticlePage,
});

function ArticlePage() {
  const { article } = Route.useLoaderData();

  return (
    <main className="page-in">
      <Container className="py-12 md:py-16">
        <nav className="text-sm text-muted" aria-label="Хлебные крошки">
          <Link to="/materials" className="prose-link">
            Материалы
          </Link>
          <span aria-hidden> / </span>
          <span>{article.kind}</span>
        </nav>
        <article className="mt-6 max-w-prose">
          <p className="text-sm text-accent">
            {article.kind} · {article.minutes} мин чтения
          </p>
          <h1 className="display mt-3 text-4xl text-fg sm:text-5xl">{article.title}</h1>
          <p className="mt-4 text-lg text-muted">{article.lead}</p>
          {article.sections.map((section) => (
            <section key={section.heading} className="mt-10">
              <h2 className="display text-3xl">{section.heading}</h2>
              {section.paragraphs.map((paragraph) => (
                <p key={paragraph} className="mt-3 leading-relaxed">
                  {paragraph}
                </p>
              ))}
              {section.bullets ? (
                <ul className="mt-4 list-disc space-y-2 ps-5 text-muted">
                  {section.bullets.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              ) : null}
            </section>
          ))}
          <section className="mt-10 border-t border-line pt-6">
            <h2 className="text-lg">На что опирались</h2>
            <ul className="mt-3 space-y-2">
              {article.sources.map((source) => (
                <li key={source.href}>
                  <a className="prose-link" href={source.href} target="_blank" rel="noreferrer">
                    {source.label}
                  </a>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-sm text-muted">
              Ссылки ведут на сторонние сайты. «Интервал» их не контролирует и не превращает в юридическую консультацию.
            </p>
          </section>
        </article>
      </Container>
    </main>
  );
}
