import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CourseRow } from "@/components/course-row";
import { Container } from "@/components/ui";
import { filterCourses, type SortKey } from "@/lib/catalog";
import { categories } from "@/lib/data/courses";

export const Route = createFileRoute("/courses/")({
  head: () => ({
    meta: [
      { title: "Курсы — Интервал" },
      { name: "description", content: "Демонстрационный каталог курсов по киберграмотности: поиск, уровень, тема и цена." },
    ],
  }),
  component: CatalogPage,
});

const prices = [
  { id: "all", label: "Любая цена" },
  { id: "low", label: "До 3 500 ₽" },
  { id: "mid", label: "3 500–4 500 ₽" },
  { id: "high", label: "Дороже 4 500 ₽" },
];

function CatalogPage() {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("all");
  const [level, setLevel] = useState("all");
  const [price, setPrice] = useState("all");
  const [sort, setSort] = useState<SortKey>("recommended");

  const result = useMemo(
    () => filterCourses({ q, category, level, price, sort }),
    [q, category, level, price, sort],
  );

  const dirty = q !== "" || category !== "all" || level !== "all" || price !== "all" || sort !== "recommended";

  function reset() {
    setQ("");
    setCategory("all");
    setLevel("all");
    setPrice("all");
    setSort("recommended");
  }

  return (
    <main className="page-in">
      <Container className="py-12 md:py-16">
        <p className="text-sm text-muted">Каталог</p>
        <h1 className="display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl">Курсы, которые можно разобрать до записи</h1>
        <p className="mt-4 max-w-prose text-lg text-muted">
          Цены демонстрационные. Поиск и фильтры работают сразу, без запроса на сервер.
        </p>
        <div className="mt-8 grid gap-3 md:grid-cols-[minmax(0,1.4fr)_repeat(3,minmax(0,0.7fr))]">
          <label className="block">
            <span className="sr-only">Поиск по названию</span>
            <input
              className="field"
              value={q}
              placeholder="Название, навык или тема"
              onChange={(event) => setQ(event.target.value)}
            />
          </label>
          <label className="block text-sm">
            <span className="sr-only">Уровень</span>
            <select className="select" value={level} onChange={(event) => setLevel(event.target.value)}>
              <option value="all">Любой уровень</option>
              <option value="начальный">Начальный</option>
              <option value="средний">Средний</option>
            </select>
          </label>
          <label className="block text-sm">
            <span className="sr-only">Цена</span>
            <select className="select" value={price} onChange={(event) => setPrice(event.target.value)}>
              {prices.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="sr-only">Сортировка</span>
            <select className="select" value={sort} onChange={(event) => setSort(event.target.value as SortKey)}>
              <option value="recommended">Сначала основные</option>
              <option value="price-asc">Сначала дешевле</option>
              <option value="price-desc">Сначала дороже</option>
              <option value="duration">Сначала короче</option>
            </select>
          </label>
        </div>
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Тема курса">
          <button type="button" className="chip shrink-0" aria-pressed={category === "all"} onClick={() => setCategory("all")}>
            Все темы
          </button>
          {categories.map((item) => (
            <button
              key={item.id}
              type="button"
              className="chip shrink-0"
              aria-pressed={category === item.id}
              onClick={() => setCategory(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted" aria-live="polite">
          {result.length === 0 ? "Ничего не нашлось" : `Показано: ${result.length}`}
          {dirty ? (
            <button type="button" className="ms-3 underline" onClick={reset}>
              Сбросить
            </button>
          ) : null}
        </p>
        {result.length === 0 ? (
          <div className="mt-6 rounded-3xl border border-dashed border-line px-5 py-10">
            <p className="display text-3xl text-fg">Пустой результат — тоже результат</p>
            <p className="mt-3 max-w-prose text-muted">
              По этому сочетанию фильтров курсов нет. Сбросьте условия или поищите короче: например, «парол» или «фишинг».
            </p>
            <button type="button" className="btn btn-secondary mt-5" onClick={reset}>
              Показать все курсы
            </button>
          </div>
        ) : (
          <div className="mt-2 border-t border-line">
            {result.map((course) => (
              <CourseRow key={course.slug} course={course} />
            ))}
          </div>
        )}
      </Container>
    </main>
  );
}
