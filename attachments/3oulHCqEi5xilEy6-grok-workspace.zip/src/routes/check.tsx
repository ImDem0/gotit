import { createFileRoute } from "@tanstack/react-router";
import { QuizView } from "@/components/quiz-view";
import { Container } from "@/components/ui";

export const Route = createFileRoute("/check")({
  head: () => ({
    meta: [
      { title: "Проверка — Интервал" },
      { name: "description", content: "Учебный тест по бытовой киберграмотности с пояснением после каждого ответа." },
    ],
  }),
  component: CheckPage,
});

function CheckPage() {
  return (
    <main className="page-in">
      <Container className="py-12 md:py-16">
        <p className="text-sm text-muted">Проверка</p>
        <h1 className="display mt-3 max-w-3xl text-4xl text-fg sm:text-6xl">Десять минут без настоящих секретов</h1>
        <div className="mt-8">
          <QuizView />
        </div>
      </Container>
    </main>
  );
}
