import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { DemoBanner, Button, Meter, Spinner } from "@/components/ui";
import type { Course } from "@/lib/data/courses";
import { demoOrderId, formatPrice } from "@/lib/format";
import { useProgress } from "@/lib/progress";

export function EnrollPanel({ course }: { course: Course }) {
  const { state, ready, update } = useProgress();
  const enrolled = state.enrolled.includes(course.slug);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [agree, setAgree] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const done = (state.lessons[course.slug] ?? []).length;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Напишите имя — хотя бы два символа. Оно никуда не сохранится.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Проверьте почту: нужен обычный адрес с точкой в домене.";
    if (!agree) next.agree = "Подтвердите, что понимаете: оплата не проводится.";
    setErrors(next);
    if (Object.keys(next).length) return;
    setPending(true);
    await new Promise((resolve) => setTimeout(resolve, 650));
    update((current) => ({
      ...current,
      enrolled: current.enrolled.includes(course.slug) ? current.enrolled : [...current.enrolled, course.slug],
    }));
    setPending(false);
    setName("");
    setEmail("");
    toast("Запись осталась только в этом браузере");
  }

  function clearEnrollment() {
    update((current) => ({
      ...current,
      enrolled: current.enrolled.filter((slug) => slug !== course.slug),
    }));
    toast("Демонстрационная запись снята");
  }

  return (
    <aside className="rounded-3xl border border-line bg-surface p-5 lg:sticky lg:top-24">
      <p className="text-sm text-muted">Демонстрационная цена</p>
      <p className="display mt-1 text-4xl text-fg">{formatPrice(course.price)}</p>
      <p className="mt-3 text-sm leading-relaxed text-muted">{course.format}</p>
      <div className="mt-5">
        <Meter value={ready ? done : 0} max={course.lessons.length} label="Отмечено уроков в браузере" />
      </div>
      {enrolled ? (
        <div className="mt-5 space-y-3">
          <DemoBanner>
            Запись {demoOrderId(course.slug)} сохранена локально. Деньги не списывались, письмо не отправлялось.
          </DemoBanner>
          <Button type="button" variant="secondary" onClick={clearEnrollment}>
            Снять демо-запись
          </Button>
        </div>
      ) : (
        <form className="mt-5 space-y-3" onSubmit={onSubmit} noValidate>
          <DemoBanner>Имя и почта нужны только чтобы показать сценарий. Мы не записываем их даже в браузер.</DemoBanner>
          <div>
            <label htmlFor="enroll-name" className="mb-1 block text-sm">
              Имя
            </label>
            <input
              id="enroll-name"
              className="field"
              autoComplete="name"
              value={name}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? "enroll-name-error" : undefined}
              onChange={(event) => setName(event.target.value)}
            />
            {errors.name ? (
              <p id="enroll-name-error" className="mt-1 text-sm text-danger" role="alert">
                {errors.name}
              </p>
            ) : null}
          </div>
          <div>
            <label htmlFor="enroll-email" className="mb-1 block text-sm">
              Почта
            </label>
            <input
              id="enroll-email"
              className="field"
              type="email"
              autoComplete="email"
              inputMode="email"
              value={email}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "enroll-email-error" : undefined}
              onChange={(event) => setEmail(event.target.value)}
            />
            {errors.email ? (
              <p id="enroll-email-error" className="mt-1 text-sm text-danger" role="alert">
                {errors.email}
              </p>
            ) : null}
          </div>
          <label className="flex items-start gap-3 text-sm leading-relaxed">
            <input
              type="checkbox"
              className="mt-1"
              checked={agree}
              onChange={(event) => setAgree(event.target.checked)}
            />
            <span>Понимаю, что это демонстрация и реальная оплата не выполняется.</span>
          </label>
          {errors.agree ? (
            <p className="text-sm text-danger" role="alert">
              {errors.agree}
            </p>
          ) : null}
          <Button type="submit" disabled={pending} aria-busy={pending}>
            {pending ? <Spinner /> : null}
            {pending ? "Оформляем демо" : "Оформить демо-запись"}
          </Button>
        </form>
      )}
    </aside>
  );
}
