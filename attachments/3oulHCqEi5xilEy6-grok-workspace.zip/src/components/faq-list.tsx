import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { faqItems } from "@/lib/data/faq";
import { cn } from "@/lib/cn";

export function FaqList() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="border-y border-line">
      {faqItems.map((item, index) => {
        const isOpen = open === index;
        return (
          <div key={item.q} className="border-b border-line last:border-b-0">
            <button
              type="button"
              className="flex min-h-11 w-full items-center justify-between gap-4 py-4 text-left"
              aria-expanded={isOpen}
              onClick={() => setOpen(isOpen ? null : index)}
            >
              <span className="text-lg text-fg">{item.q}</span>
              <ChevronDown className={cn("size-5 shrink-0 text-muted transition-transform duration-200", isOpen && "rotate-180")} aria-hidden />
            </button>
            <div className={cn("fold", isOpen && "open")}>
              <div className="fold-inner">
                <p className="max-w-prose pb-4 leading-relaxed text-muted">{item.a}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
