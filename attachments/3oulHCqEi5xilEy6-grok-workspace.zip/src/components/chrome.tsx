import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Moon, Sun, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Logo, Container } from "@/components/ui";
import { useProgress } from "@/lib/progress";
import { THEME_KEY, applyTheme, toggleTheme } from "@/lib/theme";
import { cn } from "@/lib/cn";

const links = [
  { to: "/courses", label: "Курсы", exact: false },
  { to: "/check", label: "Проверка", exact: true },
  { to: "/materials", label: "Материалы", exact: false },
  { to: "/author", label: "Автор", exact: true },
  { to: "/faq", label: "Вопросы", exact: true },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { state, ready } = useProgress();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      if (localStorage.getItem(THEME_KEY)) return;
      applyTheme(mq.matches ? "dark" : "light", false);
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="header-bar">
      <a href="#content" className="skip-link">
        К содержанию
      </a>
      <Container className="flex items-center gap-4 py-2">
        <Link to="/" aria-label="Интервал, на главную" className="rounded-full">
          <Logo />
        </Link>
        <nav className="ms-auto hidden items-center gap-4 md:flex" aria-label="Разделы">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              activeOptions={{ exact: link.exact }}
              className="nav-link"
              activeProps={{ className: "nav-link is-active" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        {ready && (state.quiz || state.enrolled.length > 0) ? (
          <Link to="/check" className="hidden text-sm text-muted lg:inline">
            {state.quiz ? `Тест ${state.quiz.correct}/${state.quiz.total}` : null}
            {state.quiz && state.enrolled.length > 0 ? " · " : null}
            {state.enrolled.length > 0 ? `записи ${state.enrolled.length}` : null}
          </Link>
        ) : null}
        <button
          type="button"
          className="btn btn-secondary btn-icon ms-auto md:ms-0"
          onClick={toggleTheme}
          aria-label="Сменить цветовую тему"
        >
          <span className="grid size-5">
            <Sun className="theme-icon theme-icon-light size-5" aria-hidden />
            <Moon className="theme-icon theme-icon-dark size-5" aria-hidden />
          </span>
        </button>
        <button
          type="button"
          className="btn btn-secondary btn-icon md:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((value) => !value)}
        >
          <span className="grid size-5">
            <Menu className={cn("icon-swap size-5", open && "is-off")} aria-hidden />
            <X className={cn("icon-swap size-5", !open && "is-off")} aria-hidden />
          </span>
          <span className="sr-only">{open ? "Закрыть меню" : "Открыть меню"}</span>
        </button>
      </Container>
      <div id="mobile-nav" className={cn("fold md:hidden", open && "open")}>
        <div className="fold-inner">
          <Container className="flex flex-col pb-4">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="nav-link border-t border-line"
                activeProps={{ className: "nav-link is-active" }}
                activeOptions={{ exact: link.exact }}
              >
                {link.label}
              </Link>
            ))}
          </Container>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-line">
      <Container className="grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            Цифровая грамотность без паники. Курсы, проверка и формы на этом сайте работают как демонстрация: оплаты нет, сообщения никуда не отправляются.
          </p>
        </div>
        <div>
          <p className="text-sm text-muted">Разделы</p>
          <ul className="mt-3 space-y-2">
            {links.map((link) => (
              <li key={link.to}>
                <Link to={link.to} className="text-fg">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm text-muted">Ориентиры, не реклама</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <a className="prose-link" href="https://www.cbr.ru/information_security/" target="_blank" rel="noreferrer">
                Банк России: информационная безопасность
              </a>
            </li>
            <li>
              <a className="prose-link" href="https://pages.nist.gov/800-63-4/" target="_blank" rel="noreferrer">
                NIST SP 800-63-4
              </a>
            </li>
            <li>
              <a className="prose-link" href="https://www.ncsc.gov.uk/collection/phishing-scams" target="_blank" rel="noreferrer">
                NCSC: phishing scams
              </a>
            </li>
          </ul>
        </div>
      </Container>
      <Container className="border-t border-line py-4 text-sm text-muted">
        Иванко Сергей Романович — вымышленный автор демонстрационного проекта. Биография не является реальной.
      </Container>
    </footer>
  );
}
