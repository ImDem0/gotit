import { useState } from "react";
import { cn } from "@/lib/cn";

const nodes = [
  {
    id: "mask",
    kicker: "01",
    title: "Костюм",
    chip: "Имя службы",
    text: "Письмо надевает чужое или выдуманное имя. Логотип и грамотный текст копируются легко — это не доказательство.",
  },
  {
    id: "rush",
    kicker: "02",
    title: "Спешка",
    chip: "2 часа · 49 ₽",
    text: "Короткий срок и маленькая сумма нужны, чтобы пауза показалась дороже, чем риск. Именно здесь стоит замедлиться.",
  },
  {
    id: "exit",
    kicker: "03",
    title: "Увод",
    chip: "Чужая форма",
    text: "Дальше просят карту или код на странице, которую открыли не вы. Спокойный путь — своё приложение, а не ссылка из письма.",
  },
];

export function Scheme() {
  const [active, setActive] = useState("rush");

  return (
    <div className="drift drift-late rounded-3xl border border-line bg-surface p-5 sm:p-6">
      <p className="text-sm text-muted">Как устроена обычная схема</p>
      <ol className="mt-5 grid gap-3">
        {nodes.map((node) => {
          const on = active === node.id;
          return (
            <li key={node.id}>
              <button
                type="button"
                aria-pressed={on}
                onClick={() => setActive(node.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-2xl border px-3 py-3 text-left transition-colors duration-200",
                  on ? "border-accent bg-accent-soft" : "border-line bg-bg",
                )}
              >
                <span className={cn("grid size-10 shrink-0 place-items-center rounded-full border border-line bg-surface text-sm", on && "pulse border-accent")}>
                  {node.kicker}
                </span>
                <span>
                  <span className="block text-fg">{node.title}</span>
                  <span className="block text-sm text-muted">{node.chip}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ol>
      <p className="mt-4 min-h-16 text-sm leading-relaxed text-fg" aria-live="polite">
        {nodes.find((node) => node.id === active)?.text}
      </p>
    </div>
  );
}
