import { useState } from "react";
import { cn } from "@/lib/cn";

const suspicious = {
  title: "Подозрительный вариант",
  from: "доставка@severpost-pay.example",
  body: "Посылка задержана. Оплатите сбор 49 ₽ в течение 2 часов, иначе отправление вернётся. Подтвердите адрес и данные карты на странице из этого сообщения.",
  points: [
    { id: "domain", label: "Адрес", text: "Домен .example зарезервирован для учебников и здесь стоит нарочно. В жизни смотрите не на имя службы в шапке, а на адрес целиком. Учебную строку всё равно не нужно открывать." },
    { id: "rush", label: "Два часа", text: "Короткий срок не даёт сверить заказ в спокойном приложении. Настоящая доставка обычно подождёт, пока вы откроете её сами." },
    { id: "sum", label: "49 ₽", text: "Маленькая сумма снижает сопротивление. Для схемы важнее, чтобы вы вообще ввели карту, а не размер «пошлины»." },
    { id: "card", label: "Карта", text: "Данные карты не подтверждают доставку. Их просят там, где платёж хотите начать не вы." },
  ],
};

const calm = {
  title: "Спокойный вариант",
  from: "уведомление магазина, где вы сами покупали",
  body: "Заказ готов к выдаче. Код получения лежит в приложении магазина — в письме его нет. Ничего доплачивать не нужно, ссылка для оплаты не требуется.",
  points: [
    { id: "memory", label: "Свой заказ", text: "Сообщение совпадает с покупкой, которую вы помните. Это не доказательство само по себе, но уже другой тон ситуации." },
    { id: "nocard", label: "Без доплаты", text: "Вас не ведут на новую оплату. Если доплата всё же нужна, её ищут в том же заказе, а не на случайной странице." },
    { id: "code", label: "Код не в письме", text: "Секрет получения остаётся в приложении. Письмо, которое само приносит и код, и просьбу о карте, заслуживает паузы." },
    { id: "self", label: "Свой вход", text: "Дальше вы открываете магазин так, как обычно: значок приложения или закладка, не адрес из текста." },
  ],
};

export function MessageLab() {
  const [mode, setMode] = useState<"suspicious" | "calm">("suspicious");
  const [active, setActive] = useState("domain");
  const pack = mode === "suspicious" ? suspicious : calm;
  const current = pack.points.find((point) => point.id === active) ?? pack.points[0];

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <div>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Тип сообщения">
          <button type="button" className="chip" aria-pressed={mode === "suspicious"} onClick={() => { setMode("suspicious"); setActive(suspicious.points[0].id); }}>
            Подозрительное
          </button>
          <button type="button" className="chip" aria-pressed={mode === "calm"} onClick={() => { setMode("calm"); setActive(calm.points[0].id); }}>
            Спокойное
          </button>
        </div>
        <article className="mt-4 rounded-3xl border border-line bg-surface p-5" aria-label={pack.title}>
          <p className="text-sm text-muted">{pack.title}</p>
          <p className="mt-3 text-sm text-muted">От: {pack.from}</p>
          <p className="sample mt-3 text-lg leading-relaxed text-fg">{pack.body}</p>
          <p className="mt-4 text-sm text-muted">Это учебный текст. Ссылки внутри нет, переходить некуда.</p>
        </article>
      </div>
      <div>
        <p className="text-sm text-muted">Нажмите на признак — разберём, почему он важен.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {pack.points.map((point) => (
            <button key={point.id} type="button" className="chip" aria-pressed={active === point.id} onClick={() => setActive(point.id)}>
              {point.label}
            </button>
          ))}
        </div>
        <div className={cn("mt-4 rounded-3xl border border-line bg-accent-soft p-5")} aria-live="polite">
          <p className="display text-2xl text-fg">{current.label}</p>
          <p className="mt-3 leading-relaxed text-fg">{current.text}</p>
        </div>
      </div>
    </div>
  );
}
