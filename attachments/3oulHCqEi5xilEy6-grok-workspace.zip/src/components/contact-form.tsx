import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Button, DemoBanner, Spinner } from "@/components/ui";

const topics = ["Вопрос о демо", "Ошибка на сайте", "Тема для материала", "Другое"];

export function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [topic, setTopic] = useState(topics[0]);
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "Добавьте имя — хотя бы два символа.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) next.email = "Нужна почта в обычном виде.";
    if (message.trim().length < 12) next.message = "Напишите пару слов подробнее, хотя бы 12 символов.";
    setErrors(next);
    if (Object.keys(next).length) {
      toast.error("Проверьте поля формы");
      return;
    }
    setPending(true);
    await new Promise((resolve) => setTimeout(resolve, 600));
    setPending(false);
    setSent(true);
    setName("");
    setEmail("");
    setMessage("");
    toast("Это демонстрация: сообщение никуда не ушло");
  }

  if (sent) {
    return (
      <div className="rounded-3xl border border-line bg-surface p-5">
        <h3 className="display text-3xl">Сообщение не отправлено</h3>
        <p className="mt-3 max-w-prose text-muted">
          Форма отработала локально и показала этот экран. На сервер ничего не уходило, почта не сохранялась. Так и задумано, пока у проекта нет приёма обращений.
        </p>
        <Button type="button" className="mt-5" variant="secondary" onClick={() => setSent(false)}>
          Заполнить ещё раз
        </Button>
      </div>
    );
  }

  return (
    <form className="space-y-4" onSubmit={onSubmit} noValidate>
      <DemoBanner>Поля проверяются в браузере. После «отправки» текст уничтожается и никуда не передаётся.</DemoBanner>
      <div>
        <label htmlFor="contact-name" className="mb-1 block text-sm">Имя</label>
        <input id="contact-name" className="field" autoComplete="name" value={name} aria-invalid={Boolean(errors.name)} onChange={(event) => setName(event.target.value)} />
        {errors.name ? <p className="mt-1 text-sm text-danger" role="alert">{errors.name}</p> : null}
      </div>
      <div>
        <label htmlFor="contact-email" className="mb-1 block text-sm">Почта</label>
        <input id="contact-email" className="field" type="email" autoComplete="email" value={email} aria-invalid={Boolean(errors.email)} onChange={(event) => setEmail(event.target.value)} />
        {errors.email ? <p className="mt-1 text-sm text-danger" role="alert">{errors.email}</p> : null}
      </div>
      <div>
        <label htmlFor="contact-topic" className="mb-1 block text-sm">Тема</label>
        <select id="contact-topic" className="select" value={topic} onChange={(event) => setTopic(event.target.value)}>
          {topics.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="contact-message" className="mb-1 block text-sm">Сообщение</label>
        <textarea id="contact-message" className="field" value={message} aria-invalid={Boolean(errors.message)} onChange={(event) => setMessage(event.target.value)} />
        {errors.message ? <p className="mt-1 text-sm text-danger" role="alert">{errors.message}</p> : null}
      </div>
      <Button type="submit" disabled={pending} aria-busy={pending}>
        {pending ? <Spinner /> : null}
        {pending ? "Проверяем" : "Показать демо-отправку"}
      </Button>
    </form>
  );
}
