import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { MessageLab } from "@/components/message-lab";
import { Reveal } from "@/components/reveal";
import { Scheme } from "@/components/scheme";
import { CourseRow } from "@/components/course-row";
import { ButtonLink, Container, SectionLabel } from "@/components/ui";
import { courses } from "@/lib/data/courses";
import { articles } from "@/lib/data/articles";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/cn";

const habits = [
  {
    title: "Пауза",
    text: "Срочная просьба о деньгах, коде или «подтверждении личности» почти всегда выигрывает у того, кто отвечает сразу. Десять секунд — уже навык.",
  },
  {
    title: "Источник",
    text: "Сверяйте канал, а не тон. Логотип, грамотность и знакомое имя подделываются. Надёжнее открыть сервис самим.",
  },
  {
    title: "Секрет",
    text: "Пароль, код из сообщения и данные карты не становятся безопаснее в переписке. Их не диктуют и не пересылают.",
  },
  {
    title: "Устройство",
    text: "Телефон — связка ключей. Экран запирается, система обновляется, приложения не ставятся из случайного файла.",
  },
];

const reasons = [
  { n: "01", title: "Сначала проверка", text: "Тест открыт без записи. Курс имеет смысл после того, как видно, где именно ответ разъехался." },
  { n: "02", title: "Без липовых цифр", text: "Мы не придумываем статистику потерь. Где опора внешняя, стоит ссылка на NIST, NCSC или Банк России." },
  { n: "03", title: "Учебные примеры", text: "Схемы разобраны на вымышленных текстах. Вредоносного кода и живых опасных адресов на сайте нет." },
  { n: "04", title: "Данные остаются у вас", text: "Прогресс и демо-запись живут в браузере. Общего аккаунта и скрытой отправки форм нет." },
];

export function HomeView() {
  const [habit, setHabit] = useState(0);
  const { state, ready } = useProgress();
  const popular = courses.filter((course) => course.popular);

  return (
    <div className="page-in">
      <Container className="grid items-end gap-10 py-12 md:py-20 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        <div>
          <p className="rise text-sm text-muted">Учебная платформа · не лицензированная школа</p>
          <h1 className="display rise rise-2 mt-4 text-4xl text-fg sm:text-6xl">
            Останавливаться вовремя — тоже цифровой навык.
          </h1>
          <p className="rise rise-3 mt-6 max-w-prose text-lg leading-relaxed text-muted">
            Интервал учит спокойно пользоваться интернетом: замечать мошенничество, беречь личные данные и не путать полезный сервис с ловушкой. Слоган простой — цифровая грамотность без паники.
          </p>
          <div className="rise rise-4 mt-8 flex flex-wrap gap-3">
            <ButtonLink to="/courses">Смотреть курсы</ButtonLink>
            <ButtonLink to="/check" variant="secondary">
              Проверить себя
            </ButtonLink>
          </div>
          <p className="mt-6 text-sm text-muted">{courses.length} курсов в демонстрационном каталоге · тест без регистрации</p>
        </div>
        <Scheme />
      </Container>

      {ready && (state.quiz || state.enrolled.length > 0) ? (
        <Container className="pb-4">
          <div className="rounded-3xl border border-line bg-surface px-5 py-4 text-sm text-muted">
            В этом браузере уже есть след учёбы.
            {state.quiz ? ` Тест: ${state.quiz.correct} из ${state.quiz.total}.` : ""}
            {state.enrolled.length ? ` Демо-записи: ${state.enrolled.length}.` : ""}{" "}
            <Link to="/check" className="prose-link">
              Открыть проверку
            </Link>
          </div>
        </Container>
      ) : null}

      <section className="border-y border-line" aria-labelledby="habits-title">
        <Container className="py-14 md:py-20">
          <SectionLabel index="01">Четыре привычки</SectionLabel>
          <h2 id="habits-title" className="display max-w-3xl text-4xl text-fg sm:text-5xl">
            Защита цифровой личности начинается не с программы, а с повторяемого хода.
          </h2>
          <div className="mt-8 grid gap-3 sm:grid-cols-4" role="tablist" aria-label="Привычки">
            {habits.map((item, index) => (
              <button
                key={item.title}
                type="button"
                role="tab"
                aria-selected={habit === index}
                className={cn(
                  "rounded-2xl border px-4 py-4 text-left transition-colors duration-200",
                  habit === index ? "border-accent bg-accent text-accent-fg" : "border-line bg-surface text-fg",
                )}
                onClick={() => setHabit(index)}
              >
                <span className="display text-3xl">{String(index + 1).padStart(2, "0")}</span>
                <span className="mt-2 block">{item.title}</span>
              </button>
            ))}
          </div>
          <p className="mt-6 max-w-prose text-lg leading-relaxed" aria-live="polite">
            {habits[habit]?.text}
          </p>
        </Container>
      </section>

      <section aria-labelledby="lab-title">
        <Container className="py-14 md:py-20">
          <Reveal>
            <SectionLabel index="02">Учебный разбор</SectionLabel>
            <h2 id="lab-title" className="display max-w-3xl text-4xl text-fg sm:text-5xl">
              Одно сообщение, два настроения
            </h2>
            <p className="mt-4 max-w-prose text-muted">
              Сравните давление и спокойное уведомление. Ни одна строка не является настоящей ссылкой.
            </p>
            <div className="mt-8">
              <MessageLab />
            </div>
          </Reveal>
        </Container>
      </section>

      <section className="bg-surface" aria-labelledby="courses-title">
        <Container className="py-14 md:py-20">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <SectionLabel index="03">Курсы</SectionLabel>
              <h2 id="courses-title" className="display text-4xl text-fg sm:text-5xl">
                С чего обычно начинают
              </h2>
            </div>
            <ButtonLink to="/courses" variant="secondary">
              Весь каталог
            </ButtonLink>
          </div>
          <div className="mt-6">
            {popular.map((course) => (
              <CourseRow key={course.slug} course={course} />
            ))}
          </div>
        </Container>
      </section>

      <section aria-labelledby="reasons-title">
        <Container className="py-14 md:py-20">
          <SectionLabel index="04">Как устроена платформа</SectionLabel>
          <h2 id="reasons-title" className="display max-w-3xl text-4xl text-fg sm:text-5xl">
            Честно про то, что уже работает
          </h2>
          <dl className="mt-10 grid gap-8 md:grid-cols-2">
            {reasons.map((item) => (
              <div key={item.n} className="border-t border-line pt-4">
                <dt className="display text-3xl text-fg">
                  <span className="text-accent">{item.n}</span> {item.title}
                </dt>
                <dd className="mt-2 max-w-prose text-muted">{item.text}</dd>
              </div>
            ))}
          </dl>
        </Container>
      </section>

      <section className="border-y border-line" aria-labelledby="author-title">
        <Container className="grid gap-8 py-14 md:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)] md:py-20">
          <div>
            <SectionLabel index="05">Автор сценария</SectionLabel>
            <h2 id="author-title" className="display text-4xl text-fg sm:text-5xl">
              Иванко Сергей Романович
            </h2>
            <p className="mt-4 max-w-prose text-lg leading-relaxed text-muted">
              Вымышленный методист этого демо-проекта. Он нужен, чтобы у курсов был понятный голос: без запугивания и без поддельных регалий.
            </p>
            <ButtonLink to="/author" variant="secondary" className="mt-6">
              Как устроен этот персонаж
            </ButtonLink>
          </div>
          <blockquote className="rounded-3xl bg-band px-6 py-6 text-band-fg">
            <p className="display text-3xl leading-tight">«Если письмо торопит сильнее, чем ваш собственный день, это уже содержание, а не оформление.»</p>
            <footer className="mt-4 text-sm text-band-muted">Учебная фраза персонажа, не цитата реального человека.</footer>
          </blockquote>
        </Container>
      </section>

      <section aria-labelledby="reads-title">
        <Container className="py-14 md:py-20">
          <SectionLabel index="06">Материалы</SectionLabel>
          <h2 id="reads-title" className="display text-4xl text-fg">Коротко, если курс пока не нужен</h2>
          <ul className="mt-8 divide-y divide-line border-y border-line">
            {articles.slice(0, 3).map((article) => (
              <li key={article.slug}>
                <Link to="/materials/$slug" params={{ slug: article.slug }} className="flex flex-wrap items-baseline justify-between gap-3 py-5 no-underline">
                  <span>
                    <span className="text-sm text-accent">{article.kind}</span>
                    <span className="mt-1 block text-xl text-fg">{article.title}</span>
                  </span>
                  <span className="text-sm text-muted">{article.minutes} мин</span>
                </Link>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      <section className="bg-band text-band-fg" aria-labelledby="close-title">
        <Container className="py-16 md:py-20">
          <h2 id="close-title" className="display max-w-3xl text-4xl sm:text-6xl">
            Десять минут на проверку скажут больше, чем ещё один тревожный заголовок.
          </h2>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink to="/check" variant="band">
              Пройти проверку
            </ButtonLink>
            <ButtonLink to="/courses" variant="on-band">
              Выбрать курс
            </ButtonLink>
          </div>
        </Container>
      </section>
    </div>
  );
}
