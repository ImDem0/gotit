import { Link } from "@tanstack/react-router";
import { categoryLabel, type Course } from "@/lib/data/courses";
import { formatHours, formatPrice } from "@/lib/format";

export function CourseRow({ course }: { course: Course }) {
  return (
    <Link
      to="/courses/$slug"
      params={{ slug: course.slug }}
      className="group grid gap-3 border-b border-line py-6 no-underline transition-colors duration-200 hover:bg-surface md:grid-cols-12 md:items-baseline md:gap-6 md:px-3"
    >
      <div className="md:col-span-3">
        <p className="text-sm text-accent">{categoryLabel(course.categoryId)}</p>
        <p className="mt-1 text-sm text-muted">
          {course.level} · {formatHours(course.hours)}
        </p>
      </div>
      <div className="md:col-span-6">
        <h3 className="display text-2xl text-fg group-hover:text-accent">{course.title}</h3>
        <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">{course.summary}</p>
      </div>
      <p className="display text-2xl text-fg md:col-span-3 md:text-end">
        {formatPrice(course.price)}
        <span className="mt-1 block font-sans text-xs font-normal tracking-normal text-muted">демонстрационная цена</span>
      </p>
    </Link>
  );
}
