import { Link } from "@tanstack/react-router";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "ghost" | "on-band" | "band";

export function Button({
  variant = "primary",
  className,
  ...props
}: ComponentProps<"button"> & { variant?: Variant }) {
  return <button className={cn("btn", `btn-${variant}`, className)} {...props} />;
}

export function ButtonLink({
  variant = "primary",
  className,
  ...props
}: ComponentProps<typeof Link> & { variant?: Variant }) {
  return <Link className={cn("btn", `btn-${variant}`, className)} {...props} />;
}

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-6xl px-4 sm:px-6", className)}>{children}</div>;
}

export function SectionLabel({ index, children }: { index: string; children: ReactNode }) {
  return (
    <p className="mb-4 flex items-center gap-3 text-sm text-muted">
      <span className="display text-base text-accent">{index}</span>
      <span className="h-px w-8 bg-line" aria-hidden />
      {children}
    </p>
  );
}

export function Logo() {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="grid size-7 place-items-center rounded-full bg-accent text-sm font-semibold text-accent-fg" aria-hidden>
        И
      </span>
      <span className="display text-xl text-fg">Интервал</span>
    </span>
  );
}

export function DemoBanner({ children }: { children: ReactNode }) {
  return (
    <p className="rounded-2xl border border-line bg-surface-2 px-4 py-3 text-sm leading-relaxed text-muted">
      <strong className="font-medium text-fg">Демонстрационный режим. </strong>
      {children}
    </p>
  );
}

export function Meter({ value, max, label }: { value: number; max: number; label: string }) {
  const pct = max === 0 ? 0 : Math.round((value / max) * 100);
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3 text-sm">
        <span>{label}</span>
        <span className="text-muted">
          {value} из {max}
        </span>
      </div>
      <div
        className="h-2 overflow-hidden rounded-full bg-surface-2"
        role="progressbar"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-valuetext={`${pct} процентов`}
        aria-label={label}
      >
        <div className="meter-fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Spinner() {
  return <span className="spinner" aria-hidden />;
}
