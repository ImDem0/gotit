import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button, ButtonLink, Meter } from "@/components/ui";
import { getCourse } from "@/lib/data/courses";
import { levelCopy, quizQuestions } from "@/lib/data/quiz";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/cn";

type Phase = "intro" | "question" | "result";

export function QuizView() {
  const { state, update } = useProgress();
  const [phase, setPhase] = useState<Phase>("intro");
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [checked, setChecked] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const question = quizQuestions[index];
  const correctCount = quizQuestions.filter((item) => answers[item.id] === item.correctId).length;

  function begin() {
    setPhase("question");
    setIndex(0);
    setPicked(null);
    setChecked(false);
    setAnswers({});
  }

  function confirm() {
    if (!picked || !question) return;
    setChecked(true);
    setAnswers((prev) => ({ ...prev, [question.id]: picked }));
  }

  function next() {
    if (!question) return;
    const isLast = index === quizQuestions.length - 1;
    if (isLast) {
      const finalAnswers = answers;
      const correct = quizQuestions.filter((item) => finalAnswers[item.id] === item.correctId).length;
      const missed = [...new Set(quizQuestions.filter((item) => finalAnswers[item.id] !== item.correctId).map((item) => item.courseSlug))];
      update((current) => ({
        ...current,
        quiz: { correct, total: quizQuestions.length, missed, at: new Date().toISOString() },
      }));
      setPhase("result");
      toast("Результат сохранён в этом браузере");
      return;
    }
    setIndex((value) => value + 1);
    setPicked(null);
    setChecked(false);
  }

  if (phase === "intro") {
    return (
      <div className="max-w-prose">
        <p className="leading-relaxed text-muted">
          Восемь бытовых ситуаций: письма, коды, пароли, платежи, устройство и чат с ИИ. Свои пароли и данные вводить не нужно. После выбора будет пояснение. Примеры вымышлены.
        </p>
        {state.quiz ? (
          <p className="mt-4 text-sm text-muted">
            Прошлый результат в этом браузере: {state.quiz.correct} из {state.quiz.total}.
          </p>
        ) : null}
        <Button type="button" className="mt-6" onClick={begin}>
          {state.quiz ? "Пройти ещё раз" : "Начать проверку"}
        </Button>
      </div>
    );
  }

  if (phase === "result") {
    const copy = levelCopy(correctCount, quizQuestions.length);
    const missedSlugs = [...new Set(quizQuestions.filter((item) => answers[item.id] !== item.correctId).map((item) => item.courseSlug))];
    const picks = missedSlugs.length ? missedSlugs : ["osnovy"];
    return (
      <div>
        <Meter value={correctCount} max={quizQuestions.length} label="Верные ответы" />
        <h2 className="display mt-8 text-4xl text-fg">{copy.title}</h2>
        <p className="mt-4 max-w-prose leading-relaxed text-muted">{copy.text}</p>
        <div className="mt-8 space-y-3">
          {picks.map((slug) => {
            const course = getCourse(slug);
            if (!course) return null;
            return (
              <Link key={slug} to="/courses/$slug" params={{ slug }} className="block rounded-2xl border border-line px-4 py-4 no-underline hover:bg-surface">
                <span className="text-sm text-muted">{missedSlugs.length ? "Имеет смысл посмотреть" : "Если хотите систему, начните здесь"}</span>
                <span className="mt-1 block text-lg text-fg">{course.title}</span>
              </Link>
            );
          })}
        </div>
        <h3 className="mt-10 text-lg">Разбор ответов</h3>
        <ol className="mt-4 space-y-4">
          {quizQuestions.map((item, number) => {
            const ok = answers[item.id] === item.correctId;
            return (
              <li key={item.id} className="border-b border-line pb-4">
                <p className="text-sm text-muted">
                  {number + 1}. {ok ? "Совпало" : "Есть более спокойный вариант"}
                </p>
                <p className="mt-1 text-fg">{item.prompt}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.explain}</p>
              </li>
            );
          })}
        </ol>
        <Button type="button" variant="secondary" className="mt-6" onClick={begin}>
          Пройти заново
        </Button>
      </div>
    );
  }

  if (!question) return null;
  const chosenCorrect = picked === question.correctId;

  return (
    <div>
      <Meter value={index + (checked ? 1 : 0)} max={quizQuestions.length} label="Ход проверки" />
      <p className="mt-6 text-sm text-accent">{question.topicLabel}</p>
      <h2 className="display mt-2 text-3xl text-fg sm:text-4xl">{question.prompt}</h2>
      {question.context ? <p className="mt-3 text-sm text-muted">{question.context}</p> : null}
      <div className="mt-6 grid gap-3" role="radiogroup" aria-label="Варианты">
        {question.options.map((option) => {
          const selected = picked === option.id;
          const showCorrect = checked && option.id === question.correctId;
          const showWrong = checked && selected && !chosenCorrect;
          return (
            <button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={selected}
              disabled={checked}
              onClick={() => setPicked(option.id)}
              className={cn(
                "rounded-2xl border px-4 py-4 text-left transition-colors duration-200",
                showCorrect && "border-good bg-surface",
                showWrong && "border-danger bg-surface",
                !checked && selected && "border-accent bg-accent-soft",
                !checked && !selected && "border-line bg-surface hover:bg-surface-2",
                checked && !showCorrect && !showWrong && "border-line opacity-70",
              )}
            >
              <span className="text-fg">{option.label}</span>
              {showCorrect ? <span className="mt-2 block text-sm text-good">Верный для этой ситуации ответ</span> : null}
              {showWrong ? <span className="mt-2 block text-sm text-danger">Ваш выбор</span> : null}
            </button>
          );
        })}
      </div>
      {checked ? (
        <div className="mt-5 rounded-2xl border border-line bg-surface-2 p-4" aria-live="polite">
          <p className="text-sm text-muted">{chosenCorrect ? "Да, так спокойнее." : "Здесь надёжнее другой ход."}</p>
          <p className="mt-2 leading-relaxed">{question.explain}</p>
        </div>
      ) : null}
      <div className="mt-6 flex flex-wrap gap-3">
        {!checked ? (
          <Button type="button" disabled={!picked} onClick={confirm}>
            Пояснить ответ
          </Button>
        ) : (
          <Button type="button" onClick={next}>
            {index === quizQuestions.length - 1 ? "Показать результат" : "Дальше"}
          </Button>
        )}
        <ButtonLink to="/courses" variant="ghost">
          К курсам
        </ButtonLink>
      </div>
    </div>
  );
}
