export const THEME_KEY = "interval-theme";

export function applyTheme(next: "light" | "dark", persist: boolean) {
  const root = document.documentElement;
  root.classList.add("theme-animate");
  root.dataset.theme = next;
  root.style.colorScheme = next;
  if (persist) localStorage.setItem(THEME_KEY, next);
  window.setTimeout(() => root.classList.remove("theme-animate"), 340);
}

export function toggleTheme() {
  const current = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
  applyTheme(current === "dark" ? "light" : "dark", true);
}
