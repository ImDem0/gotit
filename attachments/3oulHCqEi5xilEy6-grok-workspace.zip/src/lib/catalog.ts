import { courses, type Course } from "@/lib/data/courses";

export type SortKey = "recommended" | "price-asc" | "price-desc" | "duration";

export type CatalogQuery = {
  q: string;
  category: string;
  level: string;
  price: string;
  sort: SortKey;
};

export function filterCourses(query: CatalogQuery): Course[] {
  const q = query.q.trim().toLowerCase();
  const list = courses.filter((course) => {
    if (query.category !== "all" && course.categoryId !== query.category) return false;
    if (query.level !== "all" && course.level !== query.level) return false;
    if (query.price === "low" && course.price >= 3500) return false;
    if (query.price === "mid" && (course.price < 3500 || course.price > 4500)) return false;
    if (query.price === "high" && course.price <= 4500) return false;
    if (!q) return true;
    const hay = `${course.title} ${course.summary} ${course.skills.join(" ")}`.toLowerCase();
    return hay.includes(q);
  });

  return [...list].sort((a, b) => {
    if (query.sort === "price-asc") return a.price - b.price;
    if (query.sort === "price-desc") return b.price - a.price;
    if (query.sort === "duration") return a.hours - b.hours;
    if (a.popular !== b.popular) return a.popular ? -1 : 1;
    return a.title.localeCompare(b.title, "ru");
  });
}

export function relatedCourses(slug: string, limit = 2) {
  const current = courses.find((course) => course.slug === slug);
  if (!current) return [];
  const same = courses.filter((course) => course.slug !== slug && course.categoryId === current.categoryId);
  const rest = courses.filter((course) => course.slug !== slug && course.categoryId !== current.categoryId);
  return [...same, ...rest].slice(0, limit);
}
