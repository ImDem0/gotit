import { useEffect, useState } from "react";

export type QuizSnapshot = {
  correct: number;
  total: number;
  missed: string[];
  at: string;
};

export type ProgressState = {
  enrolled: string[];
  lessons: Record<string, number[]>;
  quiz: QuizSnapshot | null;
};

const EMPTY: ProgressState = { enrolled: [], lessons: {}, quiz: null };
export const PROGRESS_KEY = "interval-progress-v1";
const EVENT = "interval-progress";

export function loadProgress(): ProgressState {
  if (typeof window === "undefined") return EMPTY;
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw) as Partial<ProgressState>;
    return {
      enrolled: Array.isArray(parsed.enrolled) ? parsed.enrolled.filter((x) => typeof x === "string") : [],
      lessons: parsed.lessons && typeof parsed.lessons === "object" ? parsed.lessons : {},
      quiz: parsed.quiz ?? null,
    };
  } catch {
    return EMPTY;
  }
}

export function saveProgress(next: ProgressState) {
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function useProgress() {
  const [state, setState] = useState<ProgressState>(EMPTY);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const read = () => setState(loadProgress());
    read();
    setReady(true);
    window.addEventListener(EVENT, read);
    window.addEventListener("storage", read);
    return () => {
      window.removeEventListener(EVENT, read);
      window.removeEventListener("storage", read);
    };
  }, []);

  const update = (fn: (current: ProgressState) => ProgressState) => {
    const next = fn(loadProgress());
    saveProgress(next);
    setState(next);
  };

  return { state, ready, update };
}
