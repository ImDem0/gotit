const money = new Intl.NumberFormat("ru-RU");

export function formatPrice(value: number) {
  return `${money.format(value)} ₽`;
}

export function formatHours(value: number) {
  const text = Number.isInteger(value) ? String(value) : String(value).replace(".", ",");
  const whole = Math.floor(value);
  const mod10 = whole % 10;
  const mod100 = whole % 100;
  let word = "часов";
  if (mod100 < 11 || mod100 > 14) {
    if (mod10 === 1) word = "час";
    else if (mod10 >= 2 && mod10 <= 4) word = "часа";
  }
  return `${text} ${word}`;
}

export function demoOrderId(slug: string) {
  let n = 0;
  for (const ch of slug) n = (n * 33 + ch.charCodeAt(0)) % 9000;
  return `ДЕМО-${1000 + n}`;
}
